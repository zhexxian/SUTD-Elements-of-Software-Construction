package com.jkjk.MurderMansion.android;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.util.Log;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.backends.android.AndroidApplication;
import com.badlogic.gdx.backends.android.AndroidApplicationConfiguration;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesActivityResultCodes;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.Multiplayer;
import com.google.android.gms.games.multiplayer.realtime.RoomConfig;
import com.google.example.games.basegameutils.GameHelper;
import com.google.example.games.basegameutils.GameHelper.GameHelperListener;
import com.jkjk.MMHelpers.ActionResolver;
import com.jkjk.MMHelpers.MultiplayerSessionInfo;
import com.jkjk.MurderMansion.MurderMansion;

public class AndroidLauncher extends AndroidApplication implements GameHelperListener, ActionResolver {

	private final String TAG = "MurderMansion Andriod Launcher";
	// Request codes for the UIs that we show with startActivityForResult:
	final static int RC_SELECT_PLAYERS = 10000;
	final static int RC_INVITATION_INBOX = 10001;
	final static int RC_WAITING_ROOM = 10002;
	private static final int RC_SIGN_IN = 9001;

	public GameHelper gameHelper;
	public GoogleApiClient mGoogleApiClient;
	public RealTimeCommunication mRealTimeCom;
	private GPSListeners mGooglePlayListeners;
	public MultiplayerSessionInfo mMultiplayerSession;
	private MurderMansion game;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// Set log level to debug to let all gdx messages through
		this.setLogLevel(LOG_DEBUG);

		if (gameHelper == null) {
			gameHelper = new GameHelper(this, GameHelper.CLIENT_GAMES);
			gameHelper.enableDebugLog(true);
		}
		gameHelper.setMaxAutoSignInAttempts(0);
		gameHelper.setup(this);

		// Get and store api client for multi-player services
		mGoogleApiClient = gameHelper.getApiClient();

		// Initalize helper class that stores all additional needed information for multiplayer games
		mMultiplayerSession = new MultiplayerSessionInfo();
		game = new MurderMansion(this, mMultiplayerSession);

		// Initialize listener helper class
		if (mGooglePlayListeners == null) {
			mGooglePlayListeners = new GPSListeners(mGoogleApiClient, this, game);
		}
		if (mRealTimeCom == null) {
			mRealTimeCom = new RealTimeCommunication(mGoogleApiClient, this.mMultiplayerSession);
		}

		AndroidApplicationConfiguration config = new AndroidApplicationConfiguration();
		config.useImmersiveMode = true;
		initialize(game, config);

	}

	@Override
	public void onStart() {
		super.onStart();
		gameHelper.onStart(this);
	}

	@Override
	public void onStop() {
		super.onStop();
		gameHelper.onStop();
	}

	@Override
	public void onActivityResult(int requestCode, int responseCode, Intent intent) {
		super.onActivityResult(requestCode, responseCode, intent);

		switch (requestCode) {
		case RC_SELECT_PLAYERS:
			// we got the result from the "select players" UI -- ready to create the room
			handleSelectPlayersResult(responseCode, intent);
			break;
		case RC_INVITATION_INBOX:
			// we got the result from the "select invitation" UI (invitation inbox). We're
			// ready to accept the selected invitation:
			handleInvitationInboxResult(responseCode, intent);
			break;
		case RC_WAITING_ROOM:
			// we got the result from the "waiting room" UI.
			if (responseCode == Activity.RESULT_OK) {
				System.out.println("GPS room returned OK");
				// Change screen to game screen
				mMultiplayerSession.mState = mMultiplayerSession.ROOM_PLAY;
			} else if (responseCode == GamesActivityResultCodes.RESULT_LEFT_ROOM) {
				// player indicated that they want to leave the room
				mMultiplayerSession.mState = mMultiplayerSession.ROOM_MENU;
				leaveRoom();
			} else if (responseCode == Activity.RESULT_CANCELED) {
				mMultiplayerSession.mState = mMultiplayerSession.ROOM_MENU;
				// Dialog was cancelled (user pressed back key, for instance). In our game,
				// this means leaving the room too. In more elaborate games, this could mean
				// something else (like minimizing the waiting room UI).
				leaveRoom();
			}
			break;
		case RC_SIGN_IN:
			gameHelper.onActivityResult(requestCode, responseCode, intent);
			break;
		}
	}

	@Override
	public boolean getSignedInGPGS() {
		return gameHelper.isSignedIn();
	}

	@Override
	public void loginGPGS() {
		try {
			runOnUiThread(new Runnable() {
				public void run() {
					gameHelper.beginUserInitiatedSignIn();
				}
			});
		} catch (final Exception ex) {
			Gdx.app.log("MainActivity", "Log in failed: " + ex.getMessage() + ".");

		}
	}

	@Override
	public void logoutGPGS() {
		if (getSignedInGPGS()) {
			try {
				runOnUiThread(new Runnable() {
					public void run() {
						gameHelper.signOut();
					}
				});
			} catch (final Exception ex) {
				Gdx.app.log("MainActivity", "Log out failed: " + ex.getMessage() + ".");

			}
		}

	}

	@Override
	public void submitScoreGPGS(int score) {
		Games.Leaderboards.submitScore(gameHelper.getApiClient(), "CgkI6574wJUXEAIQBw", score);

	}

	@Override
	public void unlockAchievementGPGS(String achievementId) {
		Games.Achievements.unlock(gameHelper.getApiClient(), achievementId);
	}

	@Override
	public void getLeaderboardGPGS() {
		if (gameHelper.isSignedIn()) {
			startActivityForResult(
					Games.Leaderboards.getLeaderboardIntent(gameHelper.getApiClient(), "CgkI6574wJUXEAIQBw"),
					100);
		} else if (!gameHelper.isConnecting()) {
			loginGPGS();
		}
	}

	@Override
	public void getAchievementsGPGS() {
		if (gameHelper.isSignedIn()) {
			startActivityForResult(Games.Achievements.getAchievementsIntent(gameHelper.getApiClient()), 101);
		} else if (!gameHelper.isConnecting()) {
			loginGPGS();
		}
	}

	@Override
	public void onSignInFailed() {
	}

	@Override
	public void onSignInSucceeded() {
	}

	@Override
	public void startQuickGame() {
		// quick-start a game with 1 randomly selected opponent
		if (gameHelper.isSignedIn()) {
			// Set multiplayer flag to be true so that game screen will choose to create multiplayer world
			// instead
			final int MIN_OPPONENTS = 2, MAX_OPPONENTS = 5;
			Bundle autoMatchCriteria = RoomConfig.createAutoMatchCriteria(MIN_OPPONENTS, MAX_OPPONENTS, 0);

			RoomConfig.Builder rtmConfigBuilder = RoomConfig.builder(mGooglePlayListeners);
			rtmConfigBuilder.setMessageReceivedListener(mRealTimeCom);
			rtmConfigBuilder.setRoomStatusUpdateListener(mGooglePlayListeners);

			rtmConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);

			Games.RealTimeMultiplayer.create(mGoogleApiClient, rtmConfigBuilder.build());
		} else if (!gameHelper.isConnecting()) {
			loginGPGS();
		}
	}

	@Override
	public void seeInvitations() {
		if (gameHelper.isSignedIn()) {
			mMultiplayerSession.isServer = false;
			Intent intent = Games.Invitations.getInvitationInboxIntent(mGoogleApiClient);
			startActivityForResult(intent, RC_INVITATION_INBOX);
			// show list of pending invitations

		} else if (!gameHelper.isConnecting()) {
			loginGPGS();
		}
	}

	@Override
	public void sendInvitations() {
		if (gameHelper.isSignedIn()) {
			// Assign device as server and setup a socket to accept connections
			mMultiplayerSession.isServer = true;
			// show list of inevitable players
			// Choose from between 1 to 3 other opponents (APIclient,minOpponents, maxOpponents, boolean
			// Automatch)
			Intent intent = Games.RealTimeMultiplayer.getSelectOpponentsIntent(mGoogleApiClient, 1, 5);
			startActivityForResult(intent, RC_SELECT_PLAYERS);
		} else if (!gameHelper.isConnecting()) {
			loginGPGS();
		}
	}

	@Override
	// Leave the room.
	public void leaveRoom() {
		Log.d(TAG, "Leaving room.");
		if (mMultiplayerSession.mRoomId != null) {
			Games.RealTimeMultiplayer.leave(this.mGoogleApiClient, this.mGooglePlayListeners,
					mMultiplayerSession.mRoomId);
			mMultiplayerSession.endSession();
		} else {
			mMultiplayerSession.mState = mMultiplayerSession.ROOM_MENU;
		}
	}

	// Handle the result of the "Select players UI" we launched when the user clicked the
	// "Invite friends" button. We react by creating a room with those players.
	private void handleSelectPlayersResult(int response, Intent data) {
		if (response != Activity.RESULT_OK) {
			Log.w(TAG, "*** select players UI cancelled, " + response);
			mMultiplayerSession.mState = mMultiplayerSession.ROOM_MENU;
			return;
		}

		Log.d(TAG, "Select players UI succeeded.");

		// get the invitee list
		final ArrayList<String> invitees = data.getStringArrayListExtra(Games.EXTRA_PLAYER_IDS);
		Log.d(TAG, "Invitee count: " + invitees.size());

		// get the automatch criteria
		Bundle autoMatchCriteria = null;
		int minAutoMatchPlayers = data.getIntExtra(Multiplayer.EXTRA_MIN_AUTOMATCH_PLAYERS, 0);
		int maxAutoMatchPlayers = data.getIntExtra(Multiplayer.EXTRA_MAX_AUTOMATCH_PLAYERS, 0);
		if (minAutoMatchPlayers > 0 || maxAutoMatchPlayers > 0) {
			autoMatchCriteria = RoomConfig.createAutoMatchCriteria(minAutoMatchPlayers, maxAutoMatchPlayers,
					0);
			Log.d(TAG, "Automatch criteria: " + autoMatchCriteria);
		}

		// create the room
		Log.d(TAG, "Creating room...");
		RoomConfig.Builder rtmConfigBuilder = RoomConfig.builder(mGooglePlayListeners);
		rtmConfigBuilder.addPlayersToInvite(invitees);
		rtmConfigBuilder.setMessageReceivedListener(mRealTimeCom);
		rtmConfigBuilder.setRoomStatusUpdateListener(mGooglePlayListeners);
		if (autoMatchCriteria != null) {
			rtmConfigBuilder.setAutoMatchCriteria(autoMatchCriteria);
		}

		Games.RealTimeMultiplayer.create(mGoogleApiClient, rtmConfigBuilder.build());
		Log.d(TAG, "Room created, waiting for it to be ready...");
	}

	// Handle the result of the invitation inbox UI, where the player can pick an invitation
	// to accept. We react by accepting the selected invitation, if any.
	private void handleInvitationInboxResult(int response, Intent data) {
		if (response != Activity.RESULT_OK) {
			Log.w(TAG, "*** invitation inbox UI cancelled, " + response);
			mMultiplayerSession.mState = mMultiplayerSession.ROOM_MENU;
			return;
		}

		Log.d(TAG, "Invitation inbox UI succeeded.");
		Invitation inv = data.getExtras().getParcelable(Multiplayer.EXTRA_INVITATION);

		// accept invitation
		acceptInviteToRoom(inv.getInvitationId());
	}

	// Accept the given invitation.
	void acceptInviteToRoom(String invId) {
		// accept the invitation
		Log.d(TAG, "Accepting invitation: " + invId);
		RoomConfig.Builder roomConfigBuilder = RoomConfig.builder(mGooglePlayListeners);
		roomConfigBuilder.setInvitationIdToAccept(invId).setMessageReceivedListener(mRealTimeCom)
				.setRoomStatusUpdateListener(mGooglePlayListeners);
		Games.RealTimeMultiplayer.join(mGoogleApiClient, roomConfigBuilder.build());
	}

	public boolean isNetworkAvailable() {
		ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);

		NetworkInfo activeNetwork = cm.getActiveNetworkInfo();
		boolean isConnected = activeNetwork != null && activeNetwork.isConnectedOrConnecting();
		return isConnected;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jkjk.MMHelpers.ActionResolver#broadcastMessage(java.lang.String, java.lang.String)
	 */
	@Override
	public void broadcastMessage(String message, String type, boolean serverOrigin, boolean unreliable) {
		mRealTimeCom.broadcastMessage(message, type, serverOrigin, unreliable);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jkjk.MMHelpers.ActionResolver#unicastMessage(java.lang.String, int)
	 */
	@Override
	public void unicastMessage(String message, int target) {
		mRealTimeCom.unicastMessage(message, target);

	}

}
