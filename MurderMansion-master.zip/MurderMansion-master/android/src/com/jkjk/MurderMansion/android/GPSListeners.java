package com.jkjk.MurderMansion.android;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.GamesStatusCodes;
import com.google.android.gms.games.multiplayer.Invitation;
import com.google.android.gms.games.multiplayer.OnInvitationReceivedListener;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.realtime.Room;
import com.google.android.gms.games.multiplayer.realtime.RoomStatusUpdateListener;
import com.google.android.gms.games.multiplayer.realtime.RoomUpdateListener;
import com.jkjk.GameWorld.ClientMessageBuffer;
import com.jkjk.Host.MMServer;
import com.jkjk.Host.ServerMessageBuffer;
import com.jkjk.MurderMansion.MurderMansion;

public class GPSListeners implements RoomStatusUpdateListener, RoomUpdateListener,
		OnInvitationReceivedListener {

	private String TAG = "MurderMansion GPS listeners";

	// // Request codes for the UIs that we show with startActivityForResult:
	// final static int RC_SELECT_PLAYERS = 10000;
	// final static int RC_INVITATION_INBOX = 10001;
	// final static int RC_WAITING_ROOM = 10002;

	private GoogleApiClient mGoogleApiClient;
	private AndroidLauncher activity;
	private MurderMansion game;

	public GPSListeners(GoogleApiClient mGoogleApiClient, AndroidLauncher activity, MurderMansion game) {
		this.mGoogleApiClient = mGoogleApiClient;
		this.activity = activity;
		this.game = game;
	}

	// Called when we get an invitation to play a game. We react by showing that to the user.
	@Override
	public void onInvitationReceived(Invitation invitation) {
		// We got an invitation to play a game! So, store it in
		// mIncomingInvitationId
		// and show the popup on the screen.
		activity.mMultiplayerSession.mIncomingInvitationId = invitation.getInvitationId();
		Toast.makeText(activity.getApplicationContext(),
				invitation.getInviter().getDisplayName() + " is inviting you.", Toast.LENGTH_SHORT).show();
		// Create a text pop-up for invitations
	}

	@Override
	public void onInvitationRemoved(String invitationId) {
		if (activity.mMultiplayerSession.mIncomingInvitationId.equals(invitationId)) {
			activity.mMultiplayerSession.mIncomingInvitationId = null;
			// Hide invitation pop up
		}
	}

	@Override
	public void onJoinedRoom(int statusCode, Room room) {
		Log.d(TAG, "onJoinedRoom(" + statusCode + ", " + room + ")");
		if (statusCode != GamesStatusCodes.STATUS_OK) {
			Log.e(TAG, "*** Error: onRoomConnected, status " + statusCode);
			// showGameError();
			return;
		}

		// show the waiting room UI
		showWaitingRoom(room);
	}

	// Called when we've successfully left the room (this happens a result of voluntarily leaving
	// via a call to leaveRoom(). If we get disconnected, we get onDisconnectedFromRoom()).
	@Override
	public void onLeftRoom(int statusCode, String roomId) {
		// we have left the room; return to main screen.
		Log.d(TAG, "onLeftRoom, code " + statusCode);
		activity.mMultiplayerSession.mState = activity.mMultiplayerSession.ROOM_MENU;
		activity.mMultiplayerSession.endSession();
	}

	// Called when room is fully connected.
	@Override
	public void onRoomConnected(int statusCode, Room room) {
		Log.d(TAG, "onRoomConnected(" + statusCode + ", " + room + ")");

		if (statusCode != GamesStatusCodes.STATUS_OK) {
			Log.e(TAG, "*** Error: onRoomConnected, status " + statusCode);
			// showGameError();
			return;
		}

		Log.d(TAG, "Number of participants " + room.getParticipants().size());

		// Decide who is the server
		ArrayList<String> participants = room.getParticipantIds();
		Collections.sort(participants);
		if (participants.get(0).equals(activity.mMultiplayerSession.mId)) {
			activity.mMultiplayerSession.isServer = true;
		}
		ClientMessageBuffer.getInstance().emptyBuffer();
		ServerMessageBuffer.getInstance().emptyBuffer();

		if (activity.mMultiplayerSession.isServer) {
			try {
				// Create MMServer with current number of players and broadcast server details
				MMServer server = new MMServer(game, room.getParticipants().size(), false, -1);
				activity.mMultiplayerSession.setServer(server);
				Log.d(TAG, "Server created.");

			} catch (Exception e) {
				Log.d(TAG, "Error creating server " + e.getMessage());
			}
		}
	}

	// Called when room has been created
	@Override
	public void onRoomCreated(int statusCode, Room room) {
		Log.d(TAG, "onRoomCreated(" + statusCode + ", " + room + ")");
		if (statusCode != GamesStatusCodes.STATUS_OK) {
			Log.e(TAG, "*** Error: onRoomCreated, status " + statusCode);
			handleError(statusCode);
			// showGameError();
			return;
		}
		// show the waiting room UI
		showWaitingRoom(room);
	}

	// Called when we are connected to the room. We're not ready to play yet! (maybe not everybody
	// is connected yet).
	@Override
	public void onConnectedToRoom(Room room) {
		Log.d(TAG, "onConnectedToRoom.");
		Log.d(TAG, "Room id: " + room.getRoomId());
		Log.d(TAG, "Room status: " + room.getStatus());

		// get room ID, participants and my ID:
		activity.mMultiplayerSession.mRoomId = room.getRoomId();
		activity.mMultiplayerSession.mParticipants = room.getParticipants();
		activity.mMultiplayerSession.mId = room.getParticipantId(Games.Players
				.getCurrentPlayerId(mGoogleApiClient));
		activity.mMultiplayerSession.mName = room.getParticipant(
				room.getParticipantId(Games.Players.getCurrentPlayerId(mGoogleApiClient))).getDisplayName();

		// print out the list of participants (for debug purposes)
		Log.d(TAG, "Room ID: " + activity.mMultiplayerSession.mRoomId);
		Log.d(TAG, "<< CONNECTED TO ROOM>>");
	}

	// Called when we get disconnected from the room. We return to the main screen.
	@Override
	public void onDisconnectedFromRoom(Room room) {
		System.out.println("GPSListener: Disconnected from GPS room");
		activity.mMultiplayerSession.endSession();
	}

	// We treat most of the room update callbacks in the same way: we update our list of
	// participants and update the display. In a real game we would also have to check if that
	// change requires some action like removing the corresponding player avatar from the screen,
	// etc.

	@Override
	public void onPeerDeclined(Room room, List<String> arg1) {
		System.out.println("GPSListener: Peer declined");
		updateRoom(room);
	}

	@Override
	public void onPeerInvitedToRoom(Room room, List<String> arg1) {
		System.out.println("GPSListener: Peer invited");
		updateRoom(room);
	}

	@Override
	public void onP2PDisconnected(String participant) {
		System.out.println("GPSListener: P2P Disconnected");
	}

	@Override
	public void onP2PConnected(String participant) {
		System.out.println("GPSListener: P2P Connected");
	}

	@Override
	public void onPeerJoined(Room room, List<String> arg1) {
		System.out.println("GPSListener: Peer joined GPS room");
		updateRoom(room);
	}

	@Override
	public void onPeerLeft(Room room, List<String> peersWhoLeft) {
		System.out.println("GPSListener: Peer left GPS room: " + peersWhoLeft);
		// TODO: Handle player leave/disconnect
		for (String s : peersWhoLeft) {
			for (int i = 0; i < activity.mMultiplayerSession.mParticipants.size(); i++) {
				if (((Participant) activity.mMultiplayerSession.mParticipants.get(i)).getParticipantId()
						.equals(s)) {
					System.out.println("GPSListener: handling player left");
					activity.mMultiplayerSession.handlePlayerLeft(i);
					if (s.equals(activity.mMultiplayerSession.mServerId)) {
						activity.mMultiplayerSession.endSession();
					}
					break;
				}
			}
		}
		if (activity.mMultiplayerSession.mState != activity.mMultiplayerSession.ROOM_PLAY)
			updateRoom(room);
	}

	@Override
	public void onRoomAutoMatching(Room room) {
		System.out.println("GPSListener: GPS automatching");
		updateRoom(room);
	}

	@Override
	public void onRoomConnecting(Room room) {
		System.out.println("GPSListener: Connected to room");
		updateRoom(room);
	}

	@Override
	public void onPeersConnected(Room room, List<String> peers) {
		System.out.println("GPSListener: Peer connected to room");
		updateRoom(room);
	}

	@Override
	public void onPeersDisconnected(Room room, List<String> peers) {
		if (activity.mMultiplayerSession.mState != 1002)
			updateRoom(room);
	}

	private void updateRoom(Room room) {
		if (room.getParticipants() != null) {
			this.activity.mMultiplayerSession.mParticipants = room.getParticipants();
		}
		if (this.activity.mMultiplayerSession.mParticipants != null) {
		}
	}

	// Show the waiting room UI to track the progress of other players as they enter the
	// room and get connected.
	void showWaitingRoom(Room room) {
		// minimum number of players required for our game
		// For simplicity, we require everyone to join the game before we start it
		// (this is signaled by Integer.MAX_VALUE).
		final int MIN_PLAYERS = Integer.MAX_VALUE;
		Intent i = Games.RealTimeMultiplayer.getWaitingRoomIntent(mGoogleApiClient, room, MIN_PLAYERS);

		// show waiting room UI
		activity.startActivityForResult(i, AndroidLauncher.RC_WAITING_ROOM);
	}

	private void handleError(int statusCode) {
		switch (statusCode) {
		case ConnectionResult.RESOLUTION_REQUIRED:
			activity.gameHelper.beginUserInitiatedSignIn();
		}
	}

}
