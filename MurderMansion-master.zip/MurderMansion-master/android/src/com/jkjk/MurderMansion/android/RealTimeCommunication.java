package com.jkjk.MurderMansion.android;

import java.net.InetAddress;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;

import android.util.Log;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.games.Games;
import com.google.android.gms.games.multiplayer.Participant;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessage;
import com.google.android.gms.games.multiplayer.realtime.RealTimeMessageReceivedListener;
import com.jkjk.GameWorld.ClientMessageBuffer;
import com.jkjk.Host.MMServer;
import com.jkjk.Host.ServerMessageBuffer;
import com.jkjk.MMHelpers.MultiplayerSessionInfo;

public class RealTimeCommunication implements RealTimeMessageReceivedListener {
	private String TAG = "MurderMansion RealTime Communications";
	private GoogleApiClient mGoogleApiClient;
	private MultiplayerSessionInfo info;
	private ClientMessageBuffer clientMessageBuffer;
	private ServerMessageBuffer serverMessageBuffer;

	public RealTimeCommunication(GoogleApiClient api, MultiplayerSessionInfo info) {
		// this.activity=activity;
		this.mGoogleApiClient = api;
		this.info = info;
		clientMessageBuffer = ClientMessageBuffer.getInstance();
		serverMessageBuffer = ServerMessageBuffer.getInstance();
	}

	// Called when we receive a real-time message from the network.

	@Override
	public void onRealTimeMessageReceived(RealTimeMessage rtm) {
		if (info.mState != info.ROOM_PLAY && info.mState != info.ROOM_WAIT) {
			serverMessageBuffer.addMessage("endSession");
			clientMessageBuffer.addMessage("endSession");
			return;
		}

		byte[] buf = rtm.getMessageData();
		String message;

		try {
			String messageType = new String(Arrays.copyOfRange(buf, 0, 1), "UTF-8");
			message = new String(Arrays.copyOfRange(buf, 1, buf.length), "UTF-8");
//			System.out.println("RTC: Received GPS message: " + message);
//			Log.d(TAG, "MessageType: " + messageType);

			// S for server message
			if (messageType.equals("S")) {
				// Add message into message buffer
				serverMessageBuffer.addMessage(message);

				// C for client message
			} else if (messageType.equals("C")) {
				// Add message into message buffer
				clientMessageBuffer.addMessage(message);
				if (message.startsWith("init"))
					info.mServerId = rtm.getSenderParticipantId();

				// B for both
			} else if (messageType.equals("B")) {
				// Add message into message buffer
				clientMessageBuffer.addMessage(message);
				serverMessageBuffer.addMessage(message);

			} else {
				Log.d(TAG, "Message type is not recognised.");
			}

		} catch (Exception e) {
			Log.d(TAG, "Error reading from received message: " + e.getMessage());
		}
	}

	/**
	 * Broadcasts message to all parties. Message will only be handled according to their type once received.
	 * 
	 * @param message
	 *            Message to be transmitted
	 * @param type
	 *            "S" for server, "C" for client, "B" for both server and client to receive
	 * 
	 * @param serverOrigin
	 *            true if coming from server, false otherwise
	 * 
	 * @param reliable
	 *            true if unreliable message, false otherwise
	 */
	public void broadcastMessage(String message, String type, boolean serverOrigin, boolean unreliable) {


		if (serverOrigin) {
			clientMessageBuffer.addMessage(message);
		}

		if (info.isServer && (type.equals("S") || type.equals("B"))) {
			serverMessageBuffer.addMessage(message);
		}

		if (info.mRoomId == null)
			return;
		
		message = type + message;
		byte[] mMsgBuf = new byte[message.length()];

		// // Encode String Message in UTF_8 byte format for transmission
		mMsgBuf = message.getBytes(Charset.forName("UTF-8"));

		// // Send to every participant.
		for (Object o : info.mParticipants) {
			Participant p = (Participant) o;
			if (!p.isConnectedToRoom())
				continue;
			if (p.getStatus() != Participant.STATUS_JOINED)
				continue;
			if (p.getParticipantId().equals(info.mId))
				continue;
//			System.out.println("RTC: Send message: " + message);
			if (!unreliable) {
				Games.RealTimeMultiplayer.sendReliableMessage(mGoogleApiClient, null, mMsgBuf, info.mRoomId,
						p.getParticipantId());
			} else
				Games.RealTimeMultiplayer.sendUnreliableMessage(mGoogleApiClient, mMsgBuf, info.mRoomId,
						p.getParticipantId());
		}
	}

	public void unicastMessage(String message, int target) {
//		System.out.println("RTC: am i server?: " + info.isServer);
//		System.out.println("RTC: unicast message: " + message);
//		System.out.println("RTC: unicast target: " + target);

		message = "C" + message;
		byte[] mMsgBuf = new byte[message.length()];

		// // Encode String Message in UTF_8 byte format for transmission
		mMsgBuf = message.getBytes(Charset.forName("UTF-8"));

		Participant p = (Participant) info.mParticipants.get(target);

		if (p.getStatus() == Participant.STATUS_JOINED) {
			if (p.getParticipantId().equals(info.mId)) {
				clientMessageBuffer.addMessage(message.substring(1));
//				System.out.println("RTC: unicast message to self sent successfully");
				return;
			} else {
				Games.RealTimeMultiplayer.sendReliableMessage(mGoogleApiClient, null, mMsgBuf, info.mRoomId,
						p.getParticipantId());
//				System.out.println("RTC: unicast message sent successfully");
			}
		}

	}
}
