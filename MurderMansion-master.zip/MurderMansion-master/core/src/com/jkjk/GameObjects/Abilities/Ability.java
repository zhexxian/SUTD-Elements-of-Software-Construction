package com.jkjk.GameObjects.Abilities;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;


public abstract class Ability {
	
	protected Duration cooldown;
	protected GameCharacter character;
	protected boolean render;
	protected Vector2 playerPosition;
	protected float playerAngle;
	protected ShapeRenderer shapeRenderer;
	
	public Ability(GameCharacter character){
		this.character = character;
		shapeRenderer = new ShapeRenderer();
		render = false;
	}
	
	public boolean isOnCoolDown(){
		return cooldown.isCountingDown();
	}
	
	public abstract void use();
	public abstract void cooldown();
	
	public void setRenderHitBox(boolean render){
		this.render = render;
	}
	
	public void renderHitBox(OrthographicCamera cam){
		shapeRenderer.setProjectionMatrix(cam.combined);
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();
	}
	
	public void update(){
		cooldown.update();
	}


	
}
