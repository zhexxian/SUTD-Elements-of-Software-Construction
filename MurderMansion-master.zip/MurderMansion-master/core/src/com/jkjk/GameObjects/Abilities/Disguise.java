package com.jkjk.GameObjects.Abilities;

import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameObjects.Characters.Murderer;

public class Disguise extends Ability {

	private Duration duration;

	Disguise(GameCharacter character) {
		super(character);
		cooldown = new Duration(10000); // 10s cooldown
		duration = new Duration(1200);
	}

	@Override
	public void use() {
		duration.startCountdown();
		character.setMovable(false);
		if (((Murderer) character).isDisguised()) {
			((Murderer) character).setDisguise(false);
		} else {
			((Murderer) character).setDisguise(true);
		}
	}

	public void update() {
		super.update();
		if (duration.isCountingDown()) {
			duration.update();
			if (!duration.isCountingDown()) {
				character.setMovable(true);
			}
		}
	}

	@Override
	public void cooldown() {
		cooldown.startCountdown();
	}

}
