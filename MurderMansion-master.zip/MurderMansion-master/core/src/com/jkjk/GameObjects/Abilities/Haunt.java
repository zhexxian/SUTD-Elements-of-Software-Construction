package com.jkjk.GameObjects.Abilities;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.MMHelpers.AssetLoader;

public class Haunt extends Ability {

	private GameWorld gWorld;
	private Body body;
	private BodyDef bdef;
	private FixtureDef fdef;
	private Duration hitBoxExposure;

	Haunt(GameWorld gWorld, GameCharacter character) {
		super(character);
		this.gWorld = gWorld;
		bdef = new BodyDef();
		fdef = new FixtureDef();
		cooldown = new Duration(20000);
		hitBoxExposure = new Duration(50);

		bdef.type = BodyType.DynamicBody;
		bdef.position.set(0, 0);
		body = gWorld.getWorld().createBody(bdef);
		body.setActive(false);

		CircleShape shape = new CircleShape();
		shape.setRadius(25);
		fdef.shape = shape;
		fdef.isSensor = true;
		fdef.filter.maskBits = 1;
		body.createFixture(fdef).setUserData("haunt");
	}

	@Override
	public void use() {
		System.out.println("Used haunt");
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();

		body.setActive(true);
		body.setTransform(playerPosition.x, playerPosition.y, playerAngle);
		gWorld.getTM().setDisplayMessage("YOUR SOUL IS MINE!");

		hitBoxExposure.startCountdown();
		AssetLoader.hauntSFX();
	}

	@Override
	public void cooldown() {
		cooldown.startCountdown();
	}

	public void setRenderHitBox(boolean render) {
		this.render = render;
	}

	public void renderHitBox(OrthographicCamera cam) {
		if (render) {
			Gdx.gl.glEnable(GL20.GL_BLEND);
			Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
			super.renderHitBox(cam);
			shapeRenderer.identity();
			shapeRenderer.begin(ShapeType.Filled);
			shapeRenderer.setColor(0.2f, 0.8f, 0.2f, 0.2f);
			shapeRenderer.translate(playerPosition.x, playerPosition.y, 0);
			shapeRenderer.rotate(0, 0, 1, (float) (playerAngle * (180 / Math.PI)));
			shapeRenderer.circle(0, 0, 25);
			shapeRenderer.end();
			Gdx.gl.glDisable(GL20.GL_BLEND);
		}
	}

	@Override
	public void update() {
		super.update();
		hitBoxExposure.update();
		if (!hitBoxExposure.isCountingDown()) {
			if (body.isActive()) {
				body.setActive(false);
				body.setTransform(0, 0, 0);
			}
		}
	}
}
