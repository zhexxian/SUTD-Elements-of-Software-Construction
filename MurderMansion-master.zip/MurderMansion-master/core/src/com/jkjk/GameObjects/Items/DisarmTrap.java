package com.jkjk.GameObjects.Items;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;

public class DisarmTrap extends Item {

	private BodyDef bdef;
	private FixtureDef fdef;

	private Body disarmBody;
	private Duration hitBoxExposure;

	DisarmTrap(GameWorld gWorld, GameCharacter character) {
		super(gWorld, character);
		hitBoxExposure = new Duration(50);

		Vector2[] vertices = { new Vector2(11, 0), new Vector2(20, 8.9f), new Vector2(28, 5.6f),
				new Vector2(32, 0), new Vector2(28, -5.6f), new Vector2(20, -8.9f) };
		PolygonShape shape = new PolygonShape();
		shape.set(vertices);

		// Create post disarm trap
		bdef = new BodyDef();
		fdef = new FixtureDef();
		bdef.type = BodyType.DynamicBody;
		bdef.position.set(0, 0);
		disarmBody = gWorld.getWorld().createBody(bdef);
		disarmBody.setActive(false);

		fdef.shape = shape;
		fdef.isSensor = true;
		fdef.filter.maskBits = 1;

		disarmBody.createFixture(fdef).setUserData("disarm trap");
	}

	@Override
	public void startUse() {
		System.out.println("Used disarm trap");
		isInterrupted = false;
		super.startUse();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jkjk.GameObjects.Items.Item#endUse()
	 */
	@Override
	public void endUse() {

		isCompleted = false;
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();

		disarmBody.setActive(true);
		disarmBody.setTransform(playerPosition.x, playerPosition.y, playerAngle);

		hitBoxExposure.startCountdown();
		super.endUse();
	}

	public void setRenderHitBox(boolean render) {
		this.render = render;
	}

	public void renderHitBox(OrthographicCamera cam) {
		if (render) {
			Gdx.gl.glEnable(GL20.GL_BLEND);
			Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
			super.renderHitBox(cam);
			shapeRenderer.identity();
			shapeRenderer.begin(ShapeType.Filled);
			shapeRenderer.setColor(0.2f, 0.8f, 0.2f, 0.2f);
			shapeRenderer.translate(playerPosition.x, playerPosition.y, 0);
			shapeRenderer.rotate(0, 0, 1, (float) (playerAngle * (180 / Math.PI)));
			shapeRenderer.arc(10, 0, 20, -25, 50, 5);
			shapeRenderer.end();
			Gdx.gl.glDisable(GL20.GL_BLEND);
		}
	}

	@Override
	public void update() {
		super.update();
		hitBoxExposure.update();
		if (!hitBoxExposure.isCountingDown()) {
			if (disarmBody.isActive()) {
				disarmBody.setActive(false);
				disarmBody.setTransform(0, 0, 0);
				isCompleted = true;
			}
		}

	}
}
