package com.jkjk.GameObjects.Items;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;

public abstract class Item {

	protected GameWorld gWorld;
	protected boolean isCompleted;
	private Duration executionTime;
	private boolean wasInUse;
	protected boolean isInterrupted;
	protected GameCharacter character;
	protected boolean render;
	protected Vector2 playerPosition;
	protected float playerAngle;
	protected ShapeRenderer shapeRenderer;

	Item(GameWorld gWorld, GameCharacter character) {
		this.gWorld = gWorld;
		this.character = character;
		executionTime = new Duration(2000);
		shapeRenderer = new ShapeRenderer();
		render = false;
	}

	public boolean isCompleted() {
		return isCompleted;
	}

	public void startUse() {
		executionTime.startCountdown();
		character.setMovable(false);
		wasInUse = true;
	}

	public void endUse(){
		character.setMovable(true);
	}

	public void interrupt() {
		isInterrupted = true;
		wasInUse = false;
	}

	public boolean inUse() {
		return executionTime.isCountingDown() && !isInterrupted;
	}
	
	public void setRenderHitBox(boolean render){
		this.render = render;
	}
	
	public void renderHitBox(OrthographicCamera cam){
		shapeRenderer.setProjectionMatrix(cam.combined);
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();
	}

	public void update() {
		if (!isInterrupted) {
			executionTime.update();
			if (wasInUse && !inUse()) {
				endUse();
				wasInUse = false;
			}
		}
	}
}
