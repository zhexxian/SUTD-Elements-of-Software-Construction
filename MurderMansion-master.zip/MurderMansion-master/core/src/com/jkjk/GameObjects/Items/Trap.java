package com.jkjk.GameObjects.Items;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.Color;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.Animation;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.CircleShape;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.MMHelpers.AssetLoader;

public class Trap extends Item {
	public MMClient client;

	private BodyDef bdef;
	private Body body;
	private Body hitBoxBody;
	private FixtureDef fdef;
	private Animation plantedTrapAnimation;
	private float animationRunTime;
	private volatile boolean plantable;

	Trap(GameWorld gWorld, MMClient client, GameCharacter character) {
		super(gWorld, character);
		this.client = client;
		bdef = new BodyDef();
		fdef = new FixtureDef();
		
		plantable = true;

		plantedTrapAnimation = AssetLoader.plantedTrapAnimation;
		animationRunTime = 0;

		bdef.type = BodyType.DynamicBody;
		bdef.position.set(new Vector2(0, 0));

		hitBoxBody = gWorld.getWorld().createBody(bdef);

		CircleShape shape = new CircleShape();
		shape.setRadius(10);
		
		fdef.shape = shape;
		fdef.isSensor = true;
		fdef.filter.maskBits = 1;

		hitBoxBody.createFixture(fdef).setUserData("hitBoxTrap");
	}

	@Override
	public void startUse() {
		System.out.println("Used trap");

		super.startUse();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.jkjk.GameObjects.Items.Item#endUse()
	 */
	@Override
	public void endUse() {
		// gWorld.getPlayer().getBody().setUserData(AssetLoader.murPlantTrapAnimation);
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();

		spawn(playerPosition.x, playerPosition.y, playerAngle);
		AssetLoader.plantTrapSound.play(AssetLoader.VOLUME);

		hitBoxBody.setActive(false);
		hitBoxBody.setTransform(0, 0,0);
		
		client.produceTrapLocation(body.getPosition().x, body.getPosition().y);

		isCompleted = true;
		super.endUse();
	}

	public void spawn(float x, float y, float angle) {
		// Gdx.app.postRunnable(new spawnRun(this,x,y,angle));

		bdef.type = BodyType.StaticBody;
		if (angle == 0) {
			bdef.position.set(x, y);
		} else {
			bdef.position.set(x + (float) (25f * Math.cos(angle)), y + (float) (25f * Math.sin(angle)));
		}

		body = gWorld.getWorld().createBody(bdef);
		body.setActive(true);
		body.setAwake(true);

		// CircleShape shape = new CircleShape();
		// shape.setRadius(10);
		//
		// fdef.shape = shape;
		// fdef.isSensor = true;
		// fdef.filter.maskBits = 1;

		body.createFixture(fdef).setUserData("trap");
		gWorld.getTrapList().put(body.getPosition(), this);
	}

	public void render(SpriteBatch batch) {
		if (gWorld.getPlayer().lightContains(body.getPosition().x, body.getPosition().y)) {
			animationRunTime += Gdx.graphics.getRawDeltaTime();
			batch.draw(plantedTrapAnimation.getKeyFrame(animationRunTime), body.getPosition().x - 16,
					body.getPosition().y - 16, 32, 32);
		}
	}

	public void setPlantable(boolean plantable) {
		this.plantable = plantable;
	}

	public boolean isPlantable() {
		return plantable;
	}

	public void setRenderHitBox(boolean render) {
		this.render = render;
	}

	public void renderHitBox(OrthographicCamera cam) {
		if (render) {
			Gdx.gl.glEnable(GL20.GL_BLEND);
			Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
			super.renderHitBox(cam);
			hitBoxBody.setTransform(playerPosition.x + (float) (25f * Math.cos(playerAngle)),
					playerPosition.y + (float) (25f * Math.sin(playerAngle)), playerAngle);
			hitBoxBody.setActive(true);
			hitBoxBody.setAwake(true);
			shapeRenderer.identity();
			shapeRenderer.begin(ShapeType.Filled);
			if (plantable) {
				shapeRenderer.setColor(0.2f, 0.8f, 0.2f, 0.2f);
			} else {
				shapeRenderer.setColor(1, 0, 0, 0.2f);
			}
			shapeRenderer.translate(playerPosition.x, playerPosition.y, 0);
			shapeRenderer.rotate(0, 0, 1, (float) (playerAngle * (180 / Math.PI)));
			shapeRenderer.circle(25, 0, 10);
			shapeRenderer.end();
			Gdx.gl.glDisable(GL20.GL_BLEND);
		}
	}

	public Body getBody() {
		return body;
	}
}
