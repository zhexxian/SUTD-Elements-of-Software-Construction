package com.jkjk.GameObjects.Weapons;

import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer.ShapeType;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef;
import com.badlogic.gdx.physics.box2d.PolygonShape;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.badlogic.gdx.physics.box2d.FixtureDef;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;

public class Bat extends Weapon {

	private BodyDef bdef;
	private FixtureDef fdef;

	Bat(GameWorld gWorld, GameCharacter character) {
		super(gWorld, character);
		bdef = new BodyDef();
		fdef = new FixtureDef();
		name = "Bat";
		bdef.type = BodyType.DynamicBody;
		bdef.position.set(0, 0);
		body = gWorld.getWorld().createBody(bdef);
		body.setActive(false);

		vertices = new Vector2[] { new Vector2(18, 0), new Vector2(34.6f, 20), new Vector2(37.6f, 13.7f),
				new Vector2(39.4f, 6.95f), new Vector2(40, 0), new Vector2(39.4f, -6.95f),
				new Vector2(37.6f, -13.7f), new Vector2(34.6f, -20) };
		PolygonShape shape = new PolygonShape();
		shape.set(vertices);
		fdef.shape = shape;
		fdef.isSensor = true;
		fdef.filter.maskBits = 1;
		body.createFixture(fdef).setUserData("bat");

	}

	public void setRenderHitBox(boolean render) {
		this.render = render;
	}

	public void renderHitBox(OrthographicCamera cam) {
		if (render) {
			Gdx.gl.glEnable(GL20.GL_BLEND);
			Gdx.gl.glBlendFunc(GL20.GL_SRC_ALPHA, GL20.GL_ONE_MINUS_SRC_ALPHA);
			super.renderHitBox(cam);
			shapeRenderer.identity();
			shapeRenderer.begin(ShapeType.Filled);
			shapeRenderer.setColor(0.2f, 0.8f, 0.2f, 0.2f);
			shapeRenderer.translate(playerPosition.x, playerPosition.y, 0);
			shapeRenderer.rotate(0, 0, 1, (float) (playerAngle * (180 / Math.PI)));
			shapeRenderer.arc(10, 0, 30, -35, 70, 5);
			shapeRenderer.end();
			Gdx.gl.glDisable(GL20.GL_BLEND);
		}
	}

	@Override
	public void use() {
		super.use();
		System.out.println("Used bat");
	}

}
