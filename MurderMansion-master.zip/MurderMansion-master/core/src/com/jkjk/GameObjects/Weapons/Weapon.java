package com.jkjk.GameObjects.Weapons;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.glutils.ShapeRenderer;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.Body;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameWorld.GameWorld;

public abstract class Weapon {

	private Duration cooldown;
	protected Duration hitBoxExposure;
	protected Body body;
	protected String name;
	protected Vector2[] vertices;
	private boolean isCompleted;
	protected GameCharacter character;
	protected Vector2 playerPosition;
	protected float playerAngle;
	protected boolean render;
	
	protected ShapeRenderer shapeRenderer;

	Weapon(GameWorld gWorld, GameCharacter character) {
		cooldown = new Duration(5000);
		this.character = character;
		hitBoxExposure = new Duration(400);
		isCompleted = false;
		shapeRenderer = new ShapeRenderer();
		render = false;
	}

	public String getName() {
		return name;
	}

	public boolean isOnCooldown() {
		return cooldown.isCountingDown();
	}

	public void use() {
		isCompleted = false;
		character.setMovable(false);
		
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();

		body.setActive(true);
		body.setAwake(true);
		body.setTransform(playerPosition.x, playerPosition.y, playerAngle);

		hitBoxExposure.startCountdown();
	}

	public void cooldown() {
		cooldown.startCountdown();
	}

	public boolean isCompleted() {
		return isCompleted;
	}
	
	public void setRenderHitBox(boolean render){
		this.render = render;
	}
	
	public void renderHitBox(OrthographicCamera cam){
		shapeRenderer.setProjectionMatrix(cam.combined);
		playerPosition = character.getBody().getPosition();
		playerAngle = character.getBody().getAngle();
	}

	public void update() {
		cooldown.update();
		hitBoxExposure.update();
		if (!hitBoxExposure.isCountingDown()) {
			if (body.isActive()) {
				body.setActive(false);
				body.setAwake(false);
				body.setTransform(0, 0, 0);
				isCompleted = true;
				character.setMovable(true);
			}
		}

	}
}
