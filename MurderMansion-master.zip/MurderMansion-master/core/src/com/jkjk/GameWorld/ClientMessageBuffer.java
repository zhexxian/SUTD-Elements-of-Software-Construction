/**
 * 
 */
package com.jkjk.GameWorld;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author LeeJunXiang
 * 
 */
public class ClientMessageBuffer {

	private static ClientMessageBuffer instance;
	private ConcurrentLinkedQueue<String> messageBuffer;

	private ClientMessageBuffer() {
		messageBuffer = new ConcurrentLinkedQueue<String>();
	}

	public static ClientMessageBuffer getInstance() {
		if (instance == null) {
			instance = new ClientMessageBuffer();
		}
		return instance;
	}

	public void addMessage(String message) {
//		System.out.println("ClientMessageBuffer message added: " + message);
		messageBuffer.offer(message);
	}

	public String getMessage() {
		return messageBuffer.poll();
	}

	public boolean isEmpty() {
		return messageBuffer.isEmpty();
	}

	public void emptyBuffer() {
		while (!messageBuffer.isEmpty()) {
			messageBuffer.poll();
		}
	}
}
