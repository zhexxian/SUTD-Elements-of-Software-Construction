package com.jkjk.GameWorld;

import java.util.ArrayList;
import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CountDownLatch;

import com.badlogic.gdx.graphics.OrthographicCamera;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.math.Vector2;
import com.badlogic.gdx.physics.box2d.BodyDef.BodyType;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameObjects.Obstacles;
import com.jkjk.GameObjects.Characters.GameCharacter;
import com.jkjk.GameObjects.Characters.GameCharacterFactory;
import com.jkjk.GameObjects.Items.ItemFactory;
import com.jkjk.GameObjects.Items.ItemSprite;
import com.jkjk.GameObjects.Weapons.WeaponFactory;
import com.jkjk.GameObjects.Weapons.WeaponPartSprite;
import com.jkjk.GameObjects.Weapons.WeaponSprite;
import com.jkjk.Host.Helpers.Location;
import com.jkjk.Host.Helpers.ObstaclesHandler;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MurderMansion.MurderMansion;

/**
 * MMClient listens to input from the Server by the host. Inputs include sharable data such as player
 * position, item spawns and player status. MMClient will also output to the server the changes made by the
 * player.
 * 
 * More importantly, client-side processing will handle all actions by the player (movement, contact). The
 * CONSEQUENCE of the action will be passed to the server, which will retransmit the results to all other
 * clients. Consequences include the removal of an item when picking it up, or change in body position due to
 * movement.
 * 
 * @author LeeJunXiang
 * 
 */
public class MMClient {

	private MurderMansion game;
	private GameWorld gWorld;
	private GameRenderer renderer;
	private ItemFactory itemFac;
	private WeaponFactory weaponFac;
	private GameCharacterFactory gameCharFac;
	private ClientMessageBuffer clientMessageBuffer;

	private boolean isGameStart;
	private CountDownLatch latch;

	private float selfAngle;
	private float selfPositionX;
	private float selfPositionY;
	private float selfVelocityX;
	private float selfVelocityY;
	private float currentPositionX;
	private float currentPositionY;

	private int numOfPlayers;
	private int id;
	private final String mName;
	private String[] clientNames;
	private int murdererId;
	private ArrayList<GameCharacter> playerList;

	private final long UPDATES_PER_SEC = 5;
	private long lastUpdated;
	private long secondUpdate;

	private final ConcurrentHashMap<String, Integer> playerIsAlive; // If 1 ->true; If 0 -> false;
	private final ConcurrentHashMap<String, Integer> playerType; // If 0 -> murderer;If 1 -> civilian; If 2 ->
																	// Ghost
	private final ConcurrentHashMap<String, float[]> playerPosition;
	private final ConcurrentHashMap<String, Float> playerAngle;
	private final ConcurrentHashMap<String, float[]> playerVelocity;
	private boolean playerIsInSafeArea;

	private ObstaclesHandler obstaclesHandler;

	private boolean tutorial;
	private GameCharacter dummy;

	private float storeLightValue;
	private Duration lightningDuration;
	private Random random;

	/**
	 * Constructs the multiplayer world, including creation of opponents.
	 * 
	 * @param gWorld
	 *            GameWorld instance
	 * @param renderer
	 *            GameRenderer instance
	 * @throws Exception
	 */
	public MMClient(MurderMansion game, GameWorld gWorld, GameRenderer renderer, boolean tutorial) {

		numOfPlayers = game.mMultiplayerSession.mParticipants.size();
		if (tutorial)
			numOfPlayers = 1;
		System.out.println("MMClient number of players: " + numOfPlayers);
		clientNames = new String[numOfPlayers];
		latch = new CountDownLatch(2);
		clientMessageBuffer = ClientMessageBuffer.getInstance();

		this.game = game;
		this.gWorld = gWorld;
		this.renderer = renderer;
		this.tutorial = tutorial;
		itemFac = new ItemFactory();
		weaponFac = new WeaponFactory();
		gameCharFac = new GameCharacterFactory();
		random = new Random();

		mName = game.mMultiplayerSession.mName;
		System.out.println("My name is : " + mName);
		isGameStart = false;

		// Set current time to last updated time
		lastUpdated = System.currentTimeMillis();
		secondUpdate = System.currentTimeMillis();

		lightningDuration = new Duration(500);

		obstaclesHandler = new ObstaclesHandler();

		playerList = new ArrayList<GameCharacter>(numOfPlayers);
		// System.out.println("Creating concurrent hashmaps for player condition.");
		playerType = new ConcurrentHashMap<String, Integer>(numOfPlayers);
		playerIsAlive = new ConcurrentHashMap<String, Integer>(numOfPlayers);
		playerPosition = new ConcurrentHashMap<String, float[]>(numOfPlayers);
		playerAngle = new ConcurrentHashMap<String, Float>(numOfPlayers);
		playerVelocity = new ConcurrentHashMap<String, float[]>(numOfPlayers);
		playerIsInSafeArea = false;

		createObstacles();
		System.out.println("Try to init players. Awaiting latch");
		while (latch.getCount() != 0) {
			if (!clientMessageBuffer.isEmpty())
				acquireMessageBuffer();
		}
		System.out.println("Latch crossed. Init now");
		initPlayers();
		System.out.println("Player initialised.");

		// Send client participant id to server
		game.actionResolver.broadcastMessage("clientName_" + id + "_" + mName, "S", false, true);

	}

	private void initPlayers() {
		System.out.println("Number of players " + numOfPlayers);
		// System.out.println("Player list size " + playerList.size());
		for (int i = 0; i < numOfPlayers; i++) {
			playerIsAlive.put("Player " + i, 1);
			if (i == id) {
				System.out.println("I'M PLAYER NUMBER " + id);
				// If self
				if (i == murdererId) {
					playerType.put("Player " + i, 0);
				} else {
					playerType.put("Player " + i, 1);
				}
				playerList.add(gWorld.createPlayer(playerType.get("Player " + id),
						playerPosition.get("Player " + i)[0], playerPosition.get("Player " + i)[1],
						playerAngle.get("Player " + i), i));
				System.out.println("Player made");
			} else {
				// Create opponent bodies
				if (i == murdererId) {
					playerList.add(gWorld.getGameCharFac().createCharacter("Murderer", i, gWorld, false));
					playerList.get(playerList.size() - 1).getBody().setType(BodyType.KinematicBody);
					playerList.get(playerList.size() - 1).spawn(playerPosition.get("Player " + i)[0],
							playerPosition.get("Player " + i)[1], playerAngle.get("Player " + i));
					playerType.put("Player " + i, 0);
					System.out.println("Player made");
				} else {
					playerList.add(gWorld.getGameCharFac().createCharacter("Civilian", i, gWorld, false));
					playerList.get(playerList.size() - 1).getBody().setType(BodyType.KinematicBody);
					playerList.get(playerList.size() - 1).spawn(playerPosition.get("Player " + i)[0],
							playerPosition.get("Player " + i)[1], playerAngle.get("Player " + i));
					playerType.put("Player " + i, 1);
					System.out.println("Player made");
				}
			}
		}
		System.out.println("Init players end");
	}

	public GameCharacter createTutorialDummy() {
		playerType.put("Player " + 100, 1);
		dummy = gameCharFac.createCharacter("Civilian", 100, gWorld, false);
		dummy.getBody().setType(BodyType.KinematicBody);
		dummy.getBody().getFixtureList().get(0).setUserData("dummy");
		dummy.spawn(gWorld.getPlayer().getBody().getPosition().x - 40, gWorld.getPlayer().getBody()
				.getPosition().y, 0);
		playerList.add(dummy);
		gWorld.setDummy(dummy);
		return dummy;
	}

	/**
	 * If 0 = DEAD; If 1 = ALIVE;
	 */
	public ConcurrentHashMap<String, Integer> getPlayerIsAlive() {
		return playerIsAlive;
	}

	/**
	 * If 0 = MURDERER; If 1 = CIVILIAN; If 2 = GHOST;
	 */
	public ConcurrentHashMap<String, Integer> getPlayerType() {
		return playerType;
	}

	public void createObstacles() {
		int i = 0;
		for (Location ob : obstaclesHandler.getObstacles()) {
			if (i == 0)
				gWorld.getObstacleList().put(new Vector2(ob.get()[0], ob.get()[1]),
						new Obstacles(gWorld, new Vector2(ob.get()[0], ob.get()[1]), 0));
			else

				gWorld.getObstacleList().put(new Vector2(ob.get()[0], ob.get()[1]),
						new Obstacles(gWorld, new Vector2(ob.get()[0], ob.get()[1]), 1));
			i++;
		}
	}

	public String[] getParticipantNames() {
		return clientNames;
	}

	/**
	 * Updates the GameWorld with other player's actions, such as player position, item positions and
	 * item/weapon use.
	 */
	public void update() {
		for (GameCharacter gc : playerList) {
			if (gc.isAlive() && !gc.isPlayer()) {
				gc.update();
			} else if (!gc.isAlive() && !gc.isPlayer()) {
				if (!tutorial) {
					currentPositionX = playerList.get(gc.getId()).getBody().getPosition().x;
					currentPositionY = playerList.get(gc.getId()).getBody().getPosition().y;

					playerList.get(gc.getId()).getBody().setActive(false);
					playerList.get(gc.getId()).getBody().setTransform(0, 0, 0);
					playerList.set(gc.getId(),
							gameCharFac.createCharacter("Ghost", gc.getId(), gWorld, false));
					playerList.get(gc.getId()).spawn(playerPosition.get("Player " + gc.getId())[0],
							playerPosition.get("Player " + gc.getId())[1],
							playerAngle.get("Player " + gc.getId()));

					playerList.get(gc.getId()).set_deathPositionX(currentPositionX);
					playerList.get(gc.getId()).set_deathPositionY(currentPositionY);
				} else {
					System.out.println("DUMMY IS DYING");
					playerList.remove(1);
					currentPositionX = dummy.getBody().getPosition().x;
					currentPositionY = dummy.getBody().getPosition().y;

					dummy.getBody().setActive(false);
					dummy.getBody().setTransform(0, 0, 0);
					dummy = gameCharFac.createCharacter("Ghost", dummy.getId(), gWorld, false);
					dummy.set_deathPositionX(currentPositionX);
					dummy.set_deathPositionY(currentPositionY);
					dummy.getBody().getFixtureList().get(0).setUserData("dummy");
					dummy.getBody().setType(BodyType.KinematicBody);
					dummy.spawn(0, 0, 0);
					gWorld.setDummy(dummy);
					playerList.add(dummy);
				}
			}
		}

		if (lightningDuration.isCountingDown()) {
			lightningDuration.update();
			if (!lightningDuration.isCountingDown()) {
				gWorld.getPlayer().setAmbientLightValue(storeLightValue);
			}
		}

		acquireMessageBuffer();

		updatePlayerLocation();
		updatePlayerIsinSafeArea();
	}

	/**
	 * Handles all message from GPS
	 * 
	 */
	private void acquireMessageBuffer() {
		while (!clientMessageBuffer.isEmpty())
			handleMessage(clientMessageBuffer.getMessage());
	}

	private void consumeItems(Vector2 position) {
		try {
			gWorld.getItemList().get(position).getBody().setActive(false);
			gWorld.getItemList().get(position).getBody().setTransform(0, 0, 0);
			gWorld.getItemList().remove(position);
		} catch (Exception e) {

		}
	}

	private void consumeWeapons(Vector2 position) {
		try {
			gWorld.getWeaponList().get(position).getBody().setActive(false);
			gWorld.getWeaponList().get(position).getBody().setTransform(0, 0, 0);
			gWorld.getWeaponList().remove(position);
		} catch (Exception e) {

		}
	}

	private void consumeWeaponParts(Vector2 position) {
		gWorld.getWeaponPartList().get(position).getBody().setActive(false);
		gWorld.getWeaponPartList().get(position).getBody().setTransform(0, 0, 0);
		gWorld.getWeaponPartList().remove(position);
	}

	private void consumeTraps(Vector2 position) {
		gWorld.getTrapList().get(position).getBody().setActive(false);
		gWorld.getTrapList().get(position).getBody().setTransform(0, 0, 0);
		gWorld.getTrapList().remove(position);

	}

	private void lightningStrike() {
		lightningDuration = new Duration(300 + random.nextInt(500));
		lightningDuration.startCountdown();
		storeLightValue = gWorld.getPlayer().getAmbientLightValue();
		gWorld.getPlayer().setAmbientLightValue(0.8f);
		AssetLoader.lightningSound.play(AssetLoader.VOLUME);
	}

	public void produceTrapLocation(float x, float y) {
		game.actionResolver.broadcastMessage(
				"trap_" + id + "_pro_" + Float.toString(x) + "_" + Float.toString(y), "C", false, true);
	}

	public void addWeaponPartCollected() {
		gWorld.addNumOfWeaponPartsCollected();
		if (gWorld.getNumOfWeaponPartsCollected() == numOfPlayers * 2)
			createShotgun();
		game.actionResolver.broadcastMessage("weaponPartCollected", "C", false, true);
	}

	public void removeTrapLocation(float x, float y) {
		game.actionResolver.broadcastMessage(
				"trap_" + id + "_con_" + Float.toString(x) + "_" + Float.toString(y), "C", false, true);
	}

	/**
	 * Remove item from MMClient item buffer and update server about consumption
	 * 
	 * @param position
	 */
	public void removeItemLocation(Vector2 position) {
		// itemLocations.consume(new Location(new float[] { position.x, position.y }));
		game.actionResolver.broadcastMessage("item_" + id + "_con_" + Float.toString(position.x) + "_"
				+ Float.toString(position.y), "B", false, true);
	}

	/**
	 * Remove item from MMClient weapon buffer and update server about consumption
	 * 
	 * @param position
	 */
	public void removeWeaponLocation(Vector2 position) {
		// weaponLocations.consume(new Location(new float[] { position.x, position.y }));
		game.actionResolver.broadcastMessage("weapon_" + id + "_con_" + Float.toString(position.x) + "_"
				+ Float.toString(position.y), "B", false, true);
	}

	/**
	 * Remove item from MMClient weapon part buffer and update server about consumption
	 * 
	 * @param position
	 */
	public void removeWeaponPartLocation(Vector2 position) {
		// weaponPartLocations.consume(new Location(new float[] { position.x, position.y }));
		game.actionResolver.broadcastMessage("weaponpart_" + id + "_con_" + Float.toString(position.x) + "_"
				+ Float.toString(position.y), "B", false, true);
	}

	/**
	 * Update MMServer that player is at game screen and ready to start game
	 * 
	 */
	public void updatePlayerIsReady() {
		game.actionResolver.broadcastMessage("ready_" + id, "S", false, false);
	}

	/**
	 * Called to update MMClients position and angle in from gWorld. Updates server if there is a change.
	 * 
	 */
	private void updatePlayerLocation() {
		if (System.currentTimeMillis() - lastUpdated <= (1 / UPDATES_PER_SEC * 1000)) {
			return;
		}
		// Get player postion
		selfAngle = gWorld.getPlayer().getBody().getAngle();
		selfPositionX = gWorld.getPlayer().getBody().getPosition().x;
		selfPositionY = gWorld.getPlayer().getBody().getPosition().y;
		selfVelocityX = gWorld.getPlayer().getBody().getLinearVelocity().x;
		selfVelocityY = gWorld.getPlayer().getBody().getLinearVelocity().y;
		// if angle and position has changed
		if ((playerPosition.get("Player " + id)[0] != selfPositionX)
				|| (playerPosition.get("Player " + id)[1] != selfPositionY)
				|| (playerAngle.get("Player " + id) != selfAngle)
				|| (playerVelocity.get("Player " + id)[0] != selfVelocityX)
				|| (playerVelocity.get("Player " + id)[1] != selfVelocityY)) {
			broadcastPlayerLocation();
		}
		lastUpdated = System.currentTimeMillis();

		if (System.currentTimeMillis() - secondUpdate >= (1 / 1 * 1000)) {
			broadcastPlayerLocation();
			secondUpdate = System.currentTimeMillis();
		}
	}

	private void broadcastPlayerLocation() {
		// Update client Hashmap
		playerPosition.put("Player " + id, new float[] { selfPositionX, selfPositionY });
		playerAngle.put("Player " + id, selfAngle);
		playerVelocity.put("Player " + id, new float[] { selfVelocityX, selfVelocityY });
		// Update clients
		game.actionResolver.broadcastMessage(
				"loc_" + id + "_" + Float.toString(selfPositionX) + "_" + Float.toString(selfPositionY) + "_"
						+ Float.toString(selfAngle) + "_" + Float.toString(selfVelocityX) + "_"
						+ Float.toString(selfVelocityY), "C", false, true);
	}

	private void updatePlayerIsinSafeArea() {
		if (gWorld.isInSafeArea() != playerIsInSafeArea) {
			playerIsInSafeArea = gWorld.isInSafeArea();
			if (playerIsInSafeArea)
				game.actionResolver.broadcastMessage("safe_" + id + "_" + 1, "S", false, true);
			else
				game.actionResolver.broadcastMessage("safe_" + id + "_" + 0, "S", false, true);
		}
	}

	/**
	 * Update server about change in player's stun status
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 1 -> true; If 0 -> false;
	 */
	public void updatePlayerIsStun(int playerID, int value) {
		game.actionResolver.broadcastMessage("stun_" + id + "_" + playerID + "_" + value, "C", false, true);
	}

	/**
	 * Update server about change in player's alive status
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 1 -> true; If 0 -> false;
	 */
	public void updatePlayerIsAlive(int playerID, int value) {
		playerIsAlive.put("Player " + id, value);
		game.actionResolver.broadcastMessage("alive_" + id + "_" + playerID + "_" + value, "B", false, true);
	}

	/**
	 * Update server about change in player's use item
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 1 -> true; If 0 -> false;
	 */
	public void updatePlayerUseItem() {
		game.actionResolver.broadcastMessage("useItem_" + id, "C", false, true);
	}

	/**
	 * Update server about change in player's use weapon
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 1 -> true; If 0 -> false;
	 */
	public void updatePlayerUseWeapon() {
		game.actionResolver.broadcastMessage("useWeapon_" + id, "C", false, true);
	}

	/**
	 * Update server about change in player's use weapon
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 1 -> true; If 0 -> false;
	 */
	public void updatePlayerUseAbility() {
		game.actionResolver.broadcastMessage("useAbility_" + id, "C", false, true);
	}

	/**
	 * Update server about change in player's type
	 * 
	 * @param playerID
	 *            ID of player status to change
	 * @param value
	 *            If 0 -> murderer; If 1 -> civilian; If 2-> Ghost;
	 */
	public void updatePlayerType(int playerID, int value) {
		playerType.put("Player " + id, value);
		game.actionResolver.broadcastMessage("type_" + id + "_" + playerID + "_" + value, "C", false, true);
	}

	/**
	 * Renders the GameRenderer with other player's move.
	 */
	public void render(OrthographicCamera cam, SpriteBatch batch) {
		for (GameCharacter gc : playerList) {
			if (gc.isAlive() && !gc.isPlayer())
				gc.render(cam, batch);
		}
	}

	/**
	 * Create item sprites on the map.
	 * 
	 * @param x
	 *            X coordinate on the map.
	 * @param y
	 *            Y coordinate on the map.
	 */
	private void createItems(float[] loc) {
		ItemSprite is = new ItemSprite(gWorld);
		gWorld.getItemList().put(new Vector2(loc[0], loc[1]), is);
		is.spawn(loc[0], loc[1], 0);
	}

	/**
	 * Create weapon sprites on the map.
	 * 
	 * @param x
	 *            X coordinate on the map.
	 * @param y
	 *            Y coordinate on the map.
	 */
	private void createWeapons(float[] loc) {
		WeaponSprite ws = new WeaponSprite(gWorld);
		gWorld.getWeaponList().put(new Vector2(loc[0], loc[1]), ws);
		ws.spawn(loc[0], loc[1], 0);
	}

	/**
	 * Create weapon part sprites on the map.
	 * 
	 * @param x
	 *            X coordinate on the map.
	 * @param y
	 *            Y coordinate on the map.
	 */
	private void createWeaponParts(float[] loc) {
		WeaponPartSprite wps = new WeaponPartSprite(gWorld);
		gWorld.getWeaponPartList().put(new Vector2(loc[0], loc[1]), wps);
		wps.spawn(loc[0], loc[1], 0);
	}

	/**
	 * @return Number of players playing the game.
	 */
	public int getNumOfPlayers() {
		return numOfPlayers;
	}

	/**
	 * @return Obtain list of players.
	 */
	public ArrayList<GameCharacter> getPlayerList() {
		return playerList;
	}

	/**
	 * Produces knife body from the player that used the knife.
	 */
	private void itemUsed(int id) {
		if (playerType.get("Player " + id) == 0) {
			playerList.get(id).addItem(itemFac.createItem("Trap", gWorld, this, playerList.get(id)));
		} else if (playerType.get("Player " + id) == 1) {
			playerList.get(id).addItem(itemFac.createItem("Disarm Trap", gWorld, this, playerList.get(id)));
		}
		playerList.get(id).useItem();
	}

	/**
	 * Player uses weapon
	 */
	private void weaponUsed(int id) {
		if (playerType.get("Player " + id) == 0) {
			if (playerList.get(id).getWeapon() == null) {
				playerList.get(id).addWeapon(weaponFac.createWeapon("Knife", gWorld, playerList.get(id)));
			}
		} else {
			if (playerList.get(id).getWeapon() == null) {
				playerList.get(id).addWeapon(weaponFac.createWeapon("Bat", gWorld, playerList.get(id)));
			}
		}
		playerList.get(id).useWeapon();
	}

	/**
	 * Creates shotgun for all players in their weapon.
	 */
	private void createShotgun() {
		for (GameCharacter gc : playerList) {
			if (gc.getType() == "Civilian") {
				gc.addWeapon(weaponFac.createWeapon("Shotgun", gWorld, gc));
			}
		}
	}

	/**
	 * Player uses ability
	 */
	private void abilityUsed(int id) {
		playerList.get(id).useAbility();
	}

	public boolean getIsGameStart() {
		return isGameStart;
	}

	public GameWorld getgWorld() {
		return gWorld;
	}

	public void setgWorld(GameWorld gWorld) {
		this.gWorld = gWorld;
	}

	public GameRenderer getRenderer() {
		return renderer;
	}

	public void setRenderer(GameRenderer renderer) {
		this.renderer = renderer;
	}

	public int getId() {
		return id;
	}

	public int getMurdererId() {
		return murdererId;
	}

	/**
	 * @param parseInt
	 */
	private void killPlayer(int id) {
		playerList.get(id).die();
	}

	private void handleInitMessage(String message) {
		String[] msg = message.split("_");

		murdererId = Integer.parseInt(msg[1]);

		for (int i = 2; i < numOfPlayers * 4 + 2; i += 4) {
			float[] position = { Float.parseFloat(msg[i + 1]), Float.parseFloat(msg[i + 2]) };
			playerPosition.put("Player " + msg[i], position);

			float angle = Float.parseFloat(msg[i + 3]);
			playerAngle.put("Player " + msg[i], angle);

			playerVelocity.put("Player " + msg[i], new float[] { 0, 0 });
		}
	}

	public void handleMessage(String message) {
//		System.out.println("MMClient handle message: " + message);
		if (message == "endSession" || message == null) {
			System.out.println("MMClient handle message null/end session caught!");
			if (!(gWorld.isCivWin() || gWorld.isMurWin())) {
				int numOfAlive = 0;
				int playerAliveId = -1;
				for (int i = 0; i < numOfPlayers; i++) {
					if (playerIsAlive.get("Player " + i) == 1) {
						numOfAlive++;
						if (i != id)
							playerAliveId = i;
					}
				}
//				System.out.println("MMClient handle message: num of alive: " + numOfAlive);
				if (numOfAlive == 2) {
					playerIsAlive.put("Player " + playerAliveId, 0);
					killPlayer(playerAliveId);
					if (playerType.get("Player " + id) == 1) {
						gWorld.setCivWin(true);
					} else {
						gWorld.setMurWin(true);
					}
				} else
					gWorld.setDisconnected(true);
				return;
			}
		}

		String[] msg = message.split("_");

		// if player position update message
		if (msg[0].equals("loc")) {
			float[] position = { Float.parseFloat(msg[2]), Float.parseFloat(msg[3]) };
			float angle = Float.parseFloat(msg[4]);
			float velocityX = Float.parseFloat(msg[5]);
			float velocityY = Float.parseFloat(msg[6]);
			playerPosition.put("Player " + msg[1], position);
			playerAngle.put("Player " + msg[1], angle);
			playerVelocity.put("Player " + msg[1], new float[] { velocityX, velocityY });
			// Get and change position of opponent
			playerList.get(Integer.parseInt(msg[1])).setPosition(position[0], position[1], angle, velocityX,
					velocityY);
		}

		// Player Status updates
		else if (msg[0].equals("type")) {
			playerType.put("Player " + Integer.parseInt(msg[2]), Integer.parseInt(msg[3]));
		} else if (msg[0].equals("alive")) {
			playerIsAlive.put("Player " + Integer.parseInt(msg[2]), Integer.parseInt(msg[3]));
			killPlayer(Integer.parseInt(msg[2]));
		} else if (msg[0].equals("stun")) {
			playerList.get(Integer.parseInt(msg[2])).stun();
		} else if (msg[0].equals("useItem")) {
			itemUsed(Integer.parseInt(msg[1]));
		} else if (msg[0].equals("useWeapon")) {
			weaponUsed(Integer.parseInt(msg[1]));
		} else if (msg[0].equals("useAbility")) {
			abilityUsed(Integer.parseInt(msg[1]));
		} else if (msg[0].equals("weaponPartCollected")) {
			gWorld.addNumOfWeaponPartsCollected();
			if (gWorld.getNumOfWeaponPartsCollected() == numOfPlayers * 2) {
				createShotgun();
			}
		}

		// If item consumption or production message
		else if (msg[0].equals("item")) {
			if (msg[2].equals("con")) {
				System.out.println("Client: Consume item");
				Vector2 position = new Vector2(Float.parseFloat(msg[3]), Float.parseFloat(msg[4]));
				consumeItems(position);

			} else if (msg[2].equals("pro")) {
				System.out.println("Client: Produce item");
				createItems(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) });
			}
		} else if (msg[0].equals("weapon")) {
			if (msg[2].equals("con")) {
				System.out.println("Client: Consume weapon");
				Vector2 position = new Vector2(Float.parseFloat(msg[3]), Float.parseFloat(msg[4]));
				consumeWeapons(position);
			} else if (msg[2].equals("pro")) {
				System.out.println("Client: Produce weapon");
				createWeapons(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) });
			}
		} else if (msg[0].equals("weaponpart")) {
			if (msg[2].equals("con")) {
				System.out.println("Client: Consume WP");
				Vector2 position = new Vector2(Float.parseFloat(msg[3]), Float.parseFloat(msg[4]));
				consumeWeaponParts(position);
			} else if (msg[2].equals("pro")) {
				System.out.println("Client: Produce weaponpart");
				createWeaponParts(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) });
			}
		} else if (msg[0].equals("trap")) {
			if (msg[2].equals("con")) {
				System.out.println("Consume trap");
				Vector2 position = new Vector2(Float.parseFloat(msg[3]), Float.parseFloat(msg[4]));
				if (gWorld.getTrapList().containsKey(position)) {
					consumeTraps(position);
				}
			} else if (msg[2].equals("pro")) {
				System.out.println("Produce trap");
				Vector2 position = new Vector2(Float.parseFloat(msg[3]), Float.parseFloat(msg[4]));
				if (Integer.parseInt(msg[1]) != id) {
					gWorld.createTrap(position);
				}
			}
		}

		else if (msg[0].equals("obstacle")) {
			System.out.println("Remove obstacle @ x:" + msg[1] + " y: " + msg[2]);
			Vector2 location = new Vector2(Float.parseFloat(msg[1]), Float.parseFloat(msg[2]));
			gWorld.removeObstacle(location);
		}

		else if (msg[0].equals("lightning")) {
			lightningStrike();
		}

		// if start game message
		else if (msg[0].equals("startgame")) {
			if (game.mMultiplayerSession.isServer)
				try {
					Thread.sleep(250);
				} catch (InterruptedException e) {
					e.printStackTrace();
				}
			isGameStart = true;
			System.out.println("All players ready. Start GAME!!");
		} else if (msg[0].equals("init")) {
			handleInitMessage(message);
			latch.countDown();
		} else if (msg[0].equals("clientId")) {
			id = Integer.parseInt(msg[1]);
			latch.countDown();
		} else if (msg[0].equals("clientNames")) {
			clientNames[Integer.parseInt(msg[1])] = msg[2];
		} else if (msg[0].equals("win")) {
			if (msg[1].equals("civilian")) {
				gWorld.setCivWin(true);
			} else if (msg[1].equals("murderer")) {
				gWorld.setMurWin(true);
			}
		}
	}

	public void endSession() {
		handleMessage("endSession");
		ClientMessageBuffer.getInstance().emptyBuffer();
		System.out.println("MMClient session ended.");
	}
}
