package com.jkjk.Host;

import java.util.ArrayList;
import java.util.concurrent.ConcurrentHashMap;

import com.jkjk.MurderMansion.MurderMansion;

public class GameStatus {
	private MurderMansion game;
	private int gameStatus;
	private int WAITING = 0;
	private int PLAYING = 1;
	private int GAMEOVER = 2;

	private String message;

	public GameStatus(MurderMansion game) {
		this.game = game;
		gameStatus = WAITING;
		message = "";
	}

	/**
	 * Signals all clients to begin the game
	 */
	public void begin() {
		message = "startgame";
		gameStatus = PLAYING;
		game.actionResolver.broadcastMessage(message, "C", true, false);
	}

	/**
	 * Sends message when someone wins the game
	 * 
	 * @param winnerType
	 *            0 for murderer win, 1 for civilian win
	 */
	public void win(int winnerType) {
		if (winnerType == 0) {
			message = "win_murderer";
		} else if (winnerType == 1) {
			message = "win_civilian";
		}
		gameStatus = GAMEOVER;
		game.actionResolver.broadcastMessage(message, "C", true, true);
	}

	/**
	 * Returns game status: 0 for waiting/ready. 1 for playing. 2 for game over.
	 * 
	 * @return Status of game.
	 */
	public int getGameStatus() {
		return gameStatus;
	}
}
