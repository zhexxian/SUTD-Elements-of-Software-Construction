package com.jkjk.Host;

import java.util.Random;
import java.util.concurrent.ConcurrentHashMap;
import com.jkjk.GameObjects.Duration;
import com.jkjk.GameWorld.ClientMessageBuffer;
import com.jkjk.Host.Helpers.Location;
import com.jkjk.Host.Helpers.ObstaclesHandler;
import com.jkjk.Host.Helpers.PlayerSpawner;
import com.jkjk.MurderMansion.MurderMansion;

public class MMServer {

	private MurderMansion game;
	private final int SERVER_ID = -1;
	public final ConcurrentHashMap<String, String> clientNames;
	private ServerMessageBuffer serverMessageBuffer;
	private String initMessage;

	private int numOfPlayers;
	private final int murdererId;
	private int[] readyList;
	private Duration gameStartPause;
	private Duration gameWait;

	private long startTime;
	private long runTime;
	private long nextItemSpawnTime;
	private long nextObstacleRemoveTime;
	private long nextLightningTime;

	private final PlayerStatuses playerStats;
	private final ObjectLocations objectLocations;
	private final ObstaclesHandler obstaclesHandler;
	private final PlayerSpawner playerSpawner;
	private float[] obstacleDestroyed; // To transmit position of obstacle destroyed to clients

	private GameStatus gameStatus;
	private int numInSafeRegion;
	private int numStillAlive;
	private boolean win;
	private Random random;

	private boolean tutorial;
	private int tutorialCharacter;

	/**
	 * @param game
	 *            The Game
	 * @param numOfPlayers
	 *            Number of players that will be playing the game
	 * @param tutorial
	 *            Is this a game for tutorial?
	 * @param tutorialCharacter
	 *            When in tutorial, 0 for murderer, 1 for civilian
	 * @throws InterruptedException
	 */
	public MMServer(MurderMansion game, int numOfPlayers, boolean tutorial, int tutorialCharacter) {

		this.game = game;
		this.numOfPlayers = numOfPlayers;
		int gameStartPauseDuration = 1000;
		if (tutorial)
			gameStartPauseDuration = 0;
		this.tutorial = tutorial;
		this.tutorialCharacter = tutorialCharacter;
		serverMessageBuffer = ServerMessageBuffer.getInstance();

		// System.out.println("Initialize Client list and listeners");
		clientNames = new ConcurrentHashMap<String, String>();
		readyList = new int[numOfPlayers];
		for (int i = 0; i < numOfPlayers; i++) {
			readyList[i] = 0;
		}

		// System.out.println("Initialize fields");
		playerStats = new PlayerStatuses(game, numOfPlayers);
		objectLocations = new ObjectLocations(game, numOfPlayers, this);
		playerSpawner = new PlayerSpawner();

		obstaclesHandler = new ObstaclesHandler();
		nextItemSpawnTime = 10000;
		nextObstacleRemoveTime = 40000;
		nextLightningTime = 20000;

		gameWait = new Duration(10000);
		gameStartPause = new Duration(gameStartPauseDuration);
		gameStatus = new GameStatus(game);
		random = new Random();

		// System.out.println("Assigning murderer");
		if (tutorial) {
			murdererId = tutorialCharacter;
		} else {
			murdererId = random.nextInt(numOfPlayers);
		}
		initPlayers();
	}

	/**
	 * Start updating only when all clients have successfully synchronized.
	 */
	public void update() {
		// Handle messages coming into server
		acquireMessageBuffer();

		// Normal operation
		if (gameStatus.getGameStatus() == 1) {
			runTime = System.currentTimeMillis() - startTime;
			handleSpawn();
			checkWin();
			lightningStrike();
		}

		// Handles Start Game countdown, then initialise
		if (gameStartPause.isCountingDown() && gameStatus.getGameStatus() == 0) {
			gameStartPause.update();
			if (!gameStartPause.isCountingDown()) {
				startTime = System.currentTimeMillis();
				gameStatus.begin();
				objectLocations.initSpawn();
				// Send client name
				for (int i = 0; i < numOfPlayers; i++) {
					String name = "";
					if (clientNames.get("Player " + i) == null) {
						name = "You";
					} else {
						name = clientNames.get("Player " + i);
					}
					game.actionResolver.broadcastMessage("clientNames_" + i + "_" + name, "C", true, true);
				}
			}
		}

		// Handle event where players are stuck on "Synchronizing..." by disconnecting the player which is not
		// ready after 10s
		else if (!gameStartPause.isCountingDown() && gameStatus.getGameStatus() == 0) {
			if (gameWait.isCountingDown()) {
				gameWait.update();
				if (!gameWait.isCountingDown()) {
					for (int i = 0; i < numOfPlayers; i++) {
						if (readyList[i] == 0) {
							game.actionResolver.unicastMessage("endSession", i);
						}
					}
					gameStartPause.startCountdown();
				}
			}
		}
	}

	/**
	 * Handles all message from GPS
	 * 
	 */
	private void acquireMessageBuffer() {
		while (!serverMessageBuffer.isEmpty())
			handleMessage(serverMessageBuffer.getMessage());
	}

	private void handleSpawn() {
		// Item/Weapon/WeaponPart Spawn
		if (runTime > nextItemSpawnTime) {
			System.out.println("SPAWN!");
			if (!objectLocations.getItemLocations().isFull()) {
				objectLocations.spawnItems(1);
				System.out.println("Item spawned with size: "
						+ objectLocations.getItemLocations().getBuffer().size());
			}
			if (!objectLocations.getWeaponLocations().isFull()) {
				objectLocations.spawnWeapons(1);
				System.out.println("Weapon spawned with size: "
						+ objectLocations.getWeaponLocations().getBuffer().size());
			}
			if (!objectLocations.getWeaponPartLocations().isFull()) {
				objectLocations.spawnWeaponParts(1);
				System.out.println("Weapon Part spawned with size: "
						+ objectLocations.getWeaponPartLocations().getBuffer().size());
			}
			nextItemSpawnTime += (random.nextInt(15000) + 10000);
		}

		// Opens random door in mansion
		if (runTime > nextObstacleRemoveTime && obstaclesHandler.getObstacles().size() > 0) {
			System.out.println("OBSTACLE DESTROYED!");
			obstacleDestroyed = obstaclesHandler.destroyObstacle().get();
			System.out.println("At x:" + obstacleDestroyed[0] + " y: " + obstacleDestroyed[1]);
			game.actionResolver.broadcastMessage("obstacle_" + Float.toString(obstacleDestroyed[0]) + "_"
					+ Float.toString(obstacleDestroyed[1]), "C", true, true);
			nextObstacleRemoveTime += 40000;
		}
	}

	private void checkWin() {
		// Civilian Win condition when murderer is dead
		if (!win && !tutorial) {
			if (playerStats.getPlayerIsAliveValue("Player " + murdererId) == 0) {
				gameStatus.win(1);
				win = true;
				return;
			}

			// Win condition when
			// (Civilian) 1) alive civilians are all in safe region or
			// (Murderer) 2) all civilians are dead
			numStillAlive = 0;
			numInSafeRegion = 0;
			for (int i = 0; i < numOfPlayers; i++) {
				if (i == murdererId)
					continue;
				if (playerStats.getPlayerIsAliveValue("Player " + i) == 1) {
					numStillAlive++;
					if (playerStats.getPlayerIsInSafeRegion("Player " + i) == 1) {
						numInSafeRegion++;
						System.out.println("ENTERED SAFE REGION!");
					}
				}
			}
			if (numStillAlive > 0 && numStillAlive == numInSafeRegion) {
				System.out.println("WHATTTT");
				gameStatus.win(1);
				win = true;
			} else if (numStillAlive == 0) {
				gameStatus.win(0);
				win = true;
			}
		}
	}

	private void lightningStrike() {
		if (runTime > nextLightningTime) {
			game.actionResolver.broadcastMessage("lightning", "C", true, true);
			nextLightningTime += (random.nextInt(15000) + 20000);
		}
	}

	private void initPlayers() {

		initMessage = "init_" + murdererId + "_";

		for (int i = 0; i < numOfPlayers; i++) {
			playerStats.getPlayerIsAlive().put("Player " + i, 1);
			playerStats.getPlayerIsInSafeRegion().put("Player " + i, 0);
			if (!tutorial) {
				if (i == murdererId) {
					playerStats.getPlayerType().put("Player " + i, 0);
				} else {
					playerStats.getPlayerType().put("Player " + i, 1);
				}
			} else {
				playerStats.getPlayerType().put("Player " + i, tutorialCharacter);
			}

			float[] playerSpawnLocation = new float[3];

			if (!tutorial)
				playerSpawnLocation = playerSpawner.getSpawnLocation();
			else
				playerSpawnLocation = new float[] { 860, 509.9347f, 3.1427f };

			initMessage += (i + "_" + playerSpawnLocation[0] + "_" + playerSpawnLocation[1] + "_"
					+ playerSpawnLocation[2] + "_");

			// Send client ID
			if (tutorial)
				ClientMessageBuffer.getInstance().addMessage("clientId_0");
			else
				game.actionResolver.unicastMessage("clientId_" + i, i);
		}
		game.actionResolver.broadcastMessage(initMessage, "C", true, false);
	}

	public int getNumOfPlayers() {
		return numOfPlayers;
	}

	public int getMurdererId() {
		return murdererId;
	}

	public GameStatus getGameStatus() {
		return gameStatus;
	}

	public PlayerStatuses getPlayerStats() {
		return playerStats;
	}

	public ObjectLocations getObjectLocations() {
		return objectLocations;
	}

	public ObstaclesHandler getObstaclesHandler() {
		return obstaclesHandler;
	}

	/**
	 * Called to handle message sent by clients
	 * 
	 * @param message
	 * @throws InterruptedException
	 * @throws NumberFormatException
	 */
	public void handleMessage(String message) {
//		System.out.println("MMServer handle message: " + message);
		if (message == "endSession" || message == null) {
			game.actionResolver.broadcastMessage("endSession", "C", false, false);
			return;
		}
		String[] msg = message.split("_");
		// If client ready message
		if (msg[0].equals("ready")) {
			readyList[Integer.parseInt(msg[1])] = 1;
			gameWait.startCountdown();
			for (int i : readyList) {
				if (i == 0)
					break;
				else
					gameStartPause.startCountdown();
			}
		} else if (msg[0].equals("clientName")) {
			clientNames.put("Player " + Integer.parseInt(msg[1]), msg[2]);
		} else if (msg[0].equals("type")) {
			playerStats.updateType(Integer.parseInt(msg[1]), Integer.parseInt(msg[2]),
					Integer.parseInt(msg[3]));
		} else if (msg[0].equals("alive")) {
			playerStats.updateIsAlive(Integer.parseInt(msg[1]), Integer.parseInt(msg[2]),
					Integer.parseInt(msg[3]));
		} else if (msg[0].equals("safe")) {
			System.out.println("Player " + msg[1] + " in safe region?: " + msg[2]);
			playerStats.updateIsInSafeRegion(Integer.parseInt(msg[1]), Integer.parseInt(msg[2]));
		}

		// If item consumption or production message
		else if (msg[0].equals("item")) {
			if (msg[2].equals("con")) {
				System.out.println("Server: Consume item");
				objectLocations.consumeItem(
						new Location(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) }),
						Integer.parseInt(msg[1]));
			}
		} else if (msg[0].equals("weapon")) {
			if (msg[2].equals("con")) {
				System.out.println("Server: Consume weapon");
				objectLocations.consumeWeapon(
						new Location(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) }),
						Integer.parseInt(msg[1]));
			}
		} else if (msg[0].equals("weaponpart")) {
			if (msg[2].equals("con")) {
				System.out.println("Server: Consume WP");
				objectLocations.consumeWeaponPart(
						new Location(new float[] { Float.parseFloat(msg[3]), Float.parseFloat(msg[4]) }),
						Integer.parseInt(msg[1]));
			}
		}
	}

	public void endSession() {
		handleMessage("endSession");
		ServerMessageBuffer.getInstance().emptyBuffer();
		System.out.println("MMServer session ended.");
	}

	public void removePlayer(int playerId) {
		killPlayer(playerId);
	}

	private void killPlayer(int playerId) {
		this.playerStats.updateIsAlive(SERVER_ID, playerId, 0);
		game.actionResolver
				.broadcastMessage("alive_" + SERVER_ID + "_" + playerId + "_" + 0, "C", true, true);
	}

}
