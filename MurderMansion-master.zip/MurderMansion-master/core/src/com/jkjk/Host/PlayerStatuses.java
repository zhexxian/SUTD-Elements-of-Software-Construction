package com.jkjk.Host;

import java.util.concurrent.ConcurrentHashMap;

import com.jkjk.MurderMansion.MurderMansion;

public class PlayerStatuses{
	private final ConcurrentHashMap<String, Integer> playerIsAlive; // If 1 -> true; If 0 -> false;
	private final ConcurrentHashMap<String, Integer> playerType; // If 0 -> murderer; If 1 -> civilian; If 2->
																	// Ghost
	private final ConcurrentHashMap<String, Integer> playerIsInSafeRegion;

	public PlayerStatuses(MurderMansion game, int numOfPlayers) {
		this.playerType = new ConcurrentHashMap<String, Integer>(numOfPlayers);
		this.playerIsAlive = new ConcurrentHashMap<String, Integer>(numOfPlayers);
		this.playerIsInSafeRegion = new ConcurrentHashMap<String, Integer>(numOfPlayers);

	}

	/**
	 * Update client alive status
	 * 
	 * @param id
	 *            Id of client to update
	 * @param status
	 *            1 -> true; 0 -> false;
	 */
	public void updateIsAlive(int origin, int id, int status) {
		playerIsAlive.put("Player " + id, status);
	}

	/**
	 * Update player type
	 * 
	 * @param origin
	 *            original sender of update
	 * @param id
	 *            id of client to update
	 * @param status
	 *            0 -> murderer; 1 -> civilian; 2-> Ghost
	 */
	public void updateType(int origin, int id, int status) {
		playerType.put("Player " + id, status);
	}

	/**
	 * Checks if player is in safe region or not
	 * 
	 * @param id
	 *            id of player
	 * @param status
	 *            If player is in safe region or not (1 is true, 0 is false)
	 */
	public void updateIsInSafeRegion(int id, int status) {
		playerIsInSafeRegion.put("Player " + id, status);
	}

	public int getPlayerIsAliveValue(String key) {
		return playerIsAlive.get(key);
	}

	public int getPlayerTypeValue(String key) {
		return playerType.get(key);
	}

	public int getPlayerIsInSafeRegion(String key) {
		return playerIsInSafeRegion.get(key);
	}

	public ConcurrentHashMap<String, Integer> getPlayerIsAlive() {
		return playerIsAlive;
	}

	public ConcurrentHashMap<String, Integer> getPlayerType() {
		return playerType;
	}

	public ConcurrentHashMap<String, Integer> getPlayerIsInSafeRegion() {
		return playerIsInSafeRegion;
	}

}
