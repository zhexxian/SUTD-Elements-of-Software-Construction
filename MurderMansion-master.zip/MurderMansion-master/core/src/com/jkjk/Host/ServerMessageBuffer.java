/**
 * 
 */
package com.jkjk.Host;

import java.util.concurrent.ConcurrentLinkedQueue;

/**
 * @author LeeJunXiang
 *
 */
public class ServerMessageBuffer {
	
	private static ServerMessageBuffer instance;
	private ConcurrentLinkedQueue<String> messageBuffer;
	
	private ServerMessageBuffer (){
		messageBuffer = new ConcurrentLinkedQueue<String>();
	}
	
	public static ServerMessageBuffer getInstance(){
		if (instance == null){
			instance = new ServerMessageBuffer();
		}
		return instance;
	}

	public void addMessage(String message) {
//		System.out.println("ServerMessageBuffer message added: " + message);
		messageBuffer.offer(message);
	}

	public String getMessage() {
		return messageBuffer.poll();
	}

	public boolean isEmpty() {
		return messageBuffer.isEmpty();
	}

	public void emptyBuffer() {
		while (!messageBuffer.isEmpty()) {
			messageBuffer.poll();
		}
	}
}
