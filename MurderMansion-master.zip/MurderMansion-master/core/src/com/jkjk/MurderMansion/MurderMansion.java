package com.jkjk.MurderMansion;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.utils.GdxNativesLoader;
import com.jkjk.MMHelpers.ActionResolver;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MMHelpers.MultiplayerSessionInfo;
import com.jkjk.Screens.SplashScreen;

public class MurderMansion extends Game {
	public ActionResolver actionResolver;
	public MultiplayerSessionInfo mMultiplayerSession;

	public static final String TITLE = "Murder Mansion";
	public static final int V_WIDTH = 640;
	public static final int V_HEIGHT = 360;
	

	public MurderMansion(ActionResolver actionResolver, MultiplayerSessionInfo mMultiplayerSession){
		this.actionResolver=actionResolver;
		this.mMultiplayerSession=mMultiplayerSession; 
	}

	@Override
	public void create() {
		GdxNativesLoader.load();
		AssetLoader.initiate();
		AssetLoader.loadLogo();
		AssetLoader.loadFont();
		AssetLoader.loadScoreScreen();
		setScreen(new SplashScreen(this));
	}

	@Override
	public void dispose() {
		super.dispose();
		AssetLoader.dispose();
		AssetLoader.disposeSFX();
	}
}