package com.jkjk.Screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.jkjk.GameWorld.GameRenderer;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.GameWorld.HudRenderer;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.Host.MMServer;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MMHelpers.MultiplayerSessionInfo;
import com.jkjk.MurderMansion.MurderMansion;

public class GameScreen implements Screen {
	private MultiplayerSessionInfo info;
	private GameWorld gWorld;
	private GameRenderer renderer;
	private HudRenderer hudRenderer;
	private float runTime;
	private MurderMansion game;

	private MMServer server;
	private MMClient client;

	public GameScreen(MurderMansion game, boolean tutorial) {

		this.game = game;
		this.info = game.mMultiplayerSession;
		this.client = info.getClient();
		this.gWorld = client.getgWorld();
		this.renderer = client.getRenderer();

		hudRenderer = new HudRenderer(game, tutorial);
	}

	@Override
	public void show() {
		AssetLoader.menuMusic.stop();
		AssetLoader.gameMusic.play();

		client.updatePlayerIsReady();
	}

	@Override
	public void render(float delta) {
		if (gWorld.isCivWin() || gWorld.isMurWin()) {
			gWorld.getGameOverTimer().update();
			if (!gWorld.getGameOverTimer().isCountingDown()) {
				System.out.println("GAMESCREEN RENDER: GAMEOVER COMPLETE");
				((Game) Gdx.app.getApplicationListener()).setScreen(new ScoreScreen(game, client));
			}
		} else if (gWorld.isDisconnected()) {
			gWorld.getGameOverTimer().update();
			if (!gWorld.getGameOverTimer().isCountingDown()) {
				System.out.println("GAMESCREEN RENDER: GAMEOVER COMPLETE");
				((Game) Gdx.app.getApplicationListener()).setScreen(new ScoreScreen(game, client));
			}
		}
		runTime += delta;
		gWorld.update(delta, client);

		renderer.render(delta, runTime, client);
		hudRenderer.render(delta, client.getIsGameStart());

		// if phone is designated server
		if (info.isServer) {
			try {
				info.getServer().update();
			} catch (NullPointerException e) {
				e.printStackTrace();
				System.out.println("Disconnected?");
			}
		}
	}

	@Override
	public void resize(int width, int height) {

	}

	@Override
	public void pause() {
		System.out.println("Pause called in GameScreen");
		if (client != null)
			client.endSession();
		if (server != null)
			server.endSession();

	}

	@Override
	public void resume() {
		
	}

	@Override
	public void hide() {
		if (client != null)
			client.endSession();
		if (server != null)
			server.endSession();
	}

	@Override
	public void dispose() {
	}
}