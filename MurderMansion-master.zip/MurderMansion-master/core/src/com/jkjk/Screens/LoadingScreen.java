/**
 * 
 */
package com.jkjk.Screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.jkjk.GameWorld.GameRenderer;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MurderMansion.MurderMansion;

/**
 * Loading Screen is used to load the game sfx (which takes a significant time to load!) and give the player a
 * mini tutorial on the game and his character
 * 
 * @author LeeJunXiang
 * 
 */
public class LoadingScreen implements Screen {
	private GameWorld gWorld;
	private GameRenderer renderer;
	private float gameWidth;
	private float gameHeight;
	private MurderMansion game;

	private MMClient client;

	private Image loadingImageCiv;
	private Image loadingImageMur;
	private Stage stage;

	private int renderLoops;

	/**
	 * Loads Game SFX and shows mini tutorial
	 */
	public LoadingScreen(MurderMansion game) {
		this.game = game;
		this.gameWidth = MurderMansion.V_WIDTH;
		this.gameHeight = MurderMansion.V_HEIGHT;
		this.client = game.mMultiplayerSession.getClient();
		this.gWorld = client.getgWorld();
		this.renderer = client.getRenderer();
		stage = new Stage(new ExtendViewport(gameWidth, gameHeight));
		renderLoops = 0;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#show()
	 */
	@Override
	public void show() {
		loadingImageCiv = new Image(AssetLoader.civLoad);
		loadingImageMur = new Image(AssetLoader.murLoad);

		if (gWorld.getPlayer().getType() == "Murderer") {
			stage.addActor(loadingImageMur);
		} else {
			stage.addActor(loadingImageCiv);
		}
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#render(float)
	 */
	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		
		stage.draw();
		stage.act();

		if (renderLoops == 500) {
			AssetLoader.loadGameSfx();
			System.out.println("Setting screen to new game screen.");
			((Game) Gdx.app.getApplicationListener()).setScreen(new GameScreen(game, false));
		}
		renderLoops++;

	}

	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	@Override
	public void pause() {
		System.out.println("Pause called in LoadingScreen");
	}

	@Override
	public void resume() {
	}

	@Override
	public void hide() {
		dispose();
	}

	@Override
	public void dispose() {
		stage.dispose();
	}
}