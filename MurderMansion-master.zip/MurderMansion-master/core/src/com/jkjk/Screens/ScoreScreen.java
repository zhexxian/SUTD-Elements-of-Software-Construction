/**
 * 
 */
package com.jkjk.Screens;

import java.util.concurrent.ConcurrentHashMap;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.Texture;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton;
import com.badlogic.gdx.scenes.scene2d.ui.ImageButton.ImageButtonStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Label;
import com.badlogic.gdx.scenes.scene2d.ui.Label.LabelStyle;
import com.badlogic.gdx.scenes.scene2d.ui.Table;
import com.badlogic.gdx.scenes.scene2d.utils.Align;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MurderMansion.MurderMansion;

/**
 * @author LeeJunXiang
 * 
 */
public class ScoreScreen implements Screen {

	private MurderMansion game;
	private String[] names;
	private int numOfNames;
	private final ConcurrentHashMap<String, Integer> playerIsAlive;
	private final ConcurrentHashMap<String, Integer> playerType;

	private Stage stage;
	private Texture score_texture;

	private float gameWidth;
	private float gameHeight;
	private float BUTTON_WIDTH;
	private float BUTTON_HEIGHT;

	private SpriteBatch batch;
	private Sprite sprite;

	private ImageButtonStyle normal1;
	private ImageButton nextButton;

	private Table table;

	private Label[] label_array;
	private LabelStyle scoreLabelStyle;

	private Image[] image_array;
	private Texture rip;
	private Texture civ_char0;
	private Texture mur_char;

	private Integer status;
	private Integer type;

	/**
	 * Score screen
	 * 
	 * @param murWin
	 *            who won the game? murderer or civilian?
	 */
	public ScoreScreen(MurderMansion game, MMClient client) {
		this.gameWidth = MurderMansion.V_WIDTH;
		this.gameHeight = MurderMansion.V_HEIGHT;
		this.game = game;
		initAssets(gameWidth, gameHeight);

		// public ScoreScreen(MurderMansion game, float gameWidth, float gameHeight) {
		// this.gameHeight=gameHeight;
		// this.gameWidth=gameWidth;
		// this.game=game;
		// initAssets(gameWidth, gameHeight);

		// names = new String[]{"wong","jx","enyan","kat"};

		names = client.getParticipantNames();
		//
		numOfNames = names.length;
		playerIsAlive = client.getPlayerIsAlive();
		playerType = client.getPlayerType();
		status = 1; // default test = alive
		type = 0; // default test = murderer

		// Create a Stage and add TouchPad
		stage = new Stage(new ExtendViewport(gameWidth, gameHeight));
		batch = new SpriteBatch();
		sprite = new Sprite(score_texture);
		sprite.setSize(Gdx.graphics.getWidth(), Gdx.graphics.getHeight());

		BUTTON_WIDTH = 60;
		BUTTON_HEIGHT = 60;

		nextButton = new ImageButton(normal1);
		table = new Table();

		label_array = new Label[numOfNames];
		image_array = new Image[numOfNames];
	}

	/**
	 * Loads images used for the HUD.
	 * 
	 * @param w
	 *            Game Width.
	 * @param h
	 *            Game Height.
	 */
	private void initAssets(float w, float h) {
		normal1 = AssetLoader.normal1;
		rip = AssetLoader.rip;
		civ_char0 = AssetLoader.civ_char0;
		mur_char = AssetLoader.mur_char;
		scoreLabelStyle = AssetLoader.scoreLabelStyle;
		score_texture = AssetLoader.score_texture;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#show()
	 */
	@Override
	public void show() {
		//Unlock An AMAZING GAME
		if(game.actionResolver.getSignedInGPGS()){
			game.actionResolver.unlockAchievementGPGS(game.actionResolver.ACHEIVEMENT_1);
		}
		
		
		table.padTop(120);

		// FIRST ROW: NAME OF PLAYERS
		for (int i = 0; i < numOfNames; i++) {
			System.out.println("Name of player: " + names[i]);
			label_array[i] = new Label(names[i], scoreLabelStyle);
			label_array[i].setAlignment(Align.center);
			label_array[i].setWrap(true);
			label_array[i].setWidth(BUTTON_WIDTH);
		}
		for (int i = 0; i < numOfNames; i++) {
			table.add(label_array[i]).size(82, 48).spaceRight(10);
		}

		table.row();
		// SECOND ROW: STATUS & TYPES OF PLAYERS
		for (int i = 0; i < numOfNames; i++) {

			// status = 1 = alive
			// if character is dead
			if (status != playerIsAlive.get("Player " + i)) {
				image_array[i] = new Image(rip);
			}
			// if character is alive
			else {
				// type = 0 = murderer
				// if character is civilian
				// TODO: ASSIGN DIFFERENT CHARACTER FOR DIFFERENT IDs
				if (type != playerType.get("Player " + i)) {
					image_array[i] = new Image(civ_char0);
				}
				// if character is murderer
				else {
					image_array[i] = new Image(mur_char);
				}
			}
		}

		for (int i = 0; i < numOfNames; i++) {
			table.add(image_array[i]).size(82, 127).spaceRight(10);
		}

		nextButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				AssetLoader.clickSound.play(AssetLoader.VOLUME);
				try {
					game.actionResolver.leaveRoom();
				} catch (Exception e) {
					System.out.println("Error on button press: " + e.getMessage());
				}
				if (game.mMultiplayerSession.mState == game.mMultiplayerSession.ROOM_MENU) {
					System.out.println("ScoreScreen: Set Screen to MenuScreen NOW!");
					((Game) Gdx.app.getApplicationListener()).setScreen(new MenuScreen(game));
				}
			}
		});

		nextButton.setSize(this.BUTTON_WIDTH, this.BUTTON_HEIGHT);
		nextButton.setPosition(560, 10);
		table.setFillParent(true);
		stage.addActor(nextButton);
		stage.addActor(table);

		Gdx.input.setInputProcessor(stage);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#render(float)
	 */
	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);
		batch.begin();
		sprite.draw(batch);
		// TODO: ANIMATION NOT WORKING :(
		// animationRunTime += Gdx.graphics.getRawDeltaTime();
		// batch.draw(score_animation.getKeyFrame(animationRunTime), 0, 0, 640, 360);
		batch.end();
		stage.draw();
		stage.act(delta); // Acts stage at deltatime
		// table.debugAll();

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#resize(int, int)
	 */
	@Override
	public void resize(int width, int height) {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#pause()
	 */
	@Override
	public void pause() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#resume()
	 */
	@Override
	public void resume() {

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#hide()
	 */
	@Override
	public void hide() {
		dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#dispose()
	 */
	@Override
	public void dispose() {
		stage.dispose();
	}

}
