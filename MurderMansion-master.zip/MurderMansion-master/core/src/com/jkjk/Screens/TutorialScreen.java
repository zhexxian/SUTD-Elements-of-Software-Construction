/**
 * 
 */
package com.jkjk.Screens;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.scenes.scene2d.InputEvent;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.scenes.scene2d.ui.Image;
import com.badlogic.gdx.scenes.scene2d.utils.ClickListener;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.jkjk.GameWorld.GameRenderer;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.Host.MMServer;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MurderMansion.MurderMansion;

/**
 * @author LeeJunXiang
 * 
 */
public class TutorialScreen implements Screen {

	private Stage stage;
	private Image page1;
	private Image civTut;
	private Image murTut;
	private Image hudTut;
	private Image screenTut;
	private Image mapTut;
	private Image civButton;
	private Image murButton;
	private Image civButtonDown;
	private Image murButtonDown;
	private Image backButton;
	private Image nextButton;

	public TutorialScreen(final MurderMansion game) {
		stage = new Stage(new ExtendViewport(MurderMansion.V_WIDTH, MurderMansion.V_HEIGHT));
		page1 = new Image(AssetLoader.tutorialP1);
		civTut = new Image(AssetLoader.civTut);
		murTut = new Image(AssetLoader.murTut);
		hudTut = new Image(AssetLoader.hudTutorial);
		screenTut = new Image(AssetLoader.screenTutorial);
		mapTut = new Image(AssetLoader.mapTutorial);

		civButton = new Image(AssetLoader.civButton);
		civButton.setPosition(464, 154);
		murButton = new Image(AssetLoader.murButton);
		murButton.setPosition(124, 154);
		civButtonDown = new Image(AssetLoader.civButtonDown);
		civButtonDown.setPosition(464, 154);
		murButtonDown = new Image(AssetLoader.murButtonDown);
		murButtonDown.setPosition(124, 154);
		backButton = new Image(AssetLoader.backButton);
		backButton.setPosition(20, 150);
		nextButton = new Image(AssetLoader.nextButton);
		nextButton.setPosition(550, 150);

		civButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				stage.clear();
				AssetLoader.clickSound.play(AssetLoader.VOLUME);
				GameWorld gWorld = new GameWorld(true);
				GameRenderer renderer = new GameRenderer(gWorld);

				try {
					game.mMultiplayerSession.isServer = true;
					game.mMultiplayerSession.setServer(new MMServer(game, 1, true, 1));
					game.mMultiplayerSession.setClient(new MMClient(game, gWorld, renderer, true));
				} catch (Exception e) {
					e.printStackTrace();
				}
				AssetLoader.loadGameSfx();
				System.out.println("Setting screen to new game screen.");
				((Game) Gdx.app.getApplicationListener()).setScreen(new GameScreen(game, true));
			}

		});

		murButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				stage.clear();
				AssetLoader.clickSound.play(AssetLoader.VOLUME);
				GameWorld gWorld = new GameWorld(true);
				GameRenderer renderer = new GameRenderer(gWorld);

				try {
					game.mMultiplayerSession.isServer = true;
					game.mMultiplayerSession.setServer(new MMServer(game, 1, true, 0));
					game.mMultiplayerSession.setClient(new MMClient(game, gWorld, renderer, true));
				} catch (Exception e) {
					System.out.println("Exception caught at TutorialScreen in murButton.addListener");
					e.printStackTrace();
				}
				AssetLoader.loadGameSfx();
				System.out.println("Setting screen to new game screen.");
				((Game) Gdx.app.getApplicationListener()).setScreen(new GameScreen(game, true));
			}

		});

		backButton.addListener(new ClickListener() {
			@Override
			public void clicked(InputEvent event, float x, float y) {
				AssetLoader.clickSound.play(AssetLoader.VOLUME);
				stage.clear();
				((Game) Gdx.app.getApplicationListener()).setScreen(new MenuScreen(game));
			}

		});

		stage.addActor(page1);
		stage.addActor(civButton);
		stage.addActor(murButton);
		stage.addActor(backButton);
		// stage.addActor(nextButton);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#show()
	 */
	@Override
	public void show() {
		Gdx.input.setInputProcessor(stage);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#render(float)
	 */
	@Override
	public void render(float delta) {
		stage.draw();
		stage.act(delta);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#resize(int, int)
	 */
	@Override
	public void resize(int width, int height) {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#pause()
	 */
	@Override
	public void pause() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#resume()
	 */
	@Override
	public void resume() {
		// TODO Auto-generated method stub

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#hide()
	 */
	@Override
	public void hide() {
		// TODO Auto-generated method stub
		dispose();
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see com.badlogic.gdx.Screen#dispose()
	 */
	@Override
	public void dispose() {
		// TODO Auto-generated method stub
		stage.dispose();
	}

}
