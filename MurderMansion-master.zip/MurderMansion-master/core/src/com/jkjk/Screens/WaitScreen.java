package com.jkjk.Screens;

import java.util.ArrayList;
import java.util.Random;

import com.badlogic.gdx.Game;
import com.badlogic.gdx.Gdx;
import com.badlogic.gdx.Screen;
import com.badlogic.gdx.graphics.GL20;
import com.badlogic.gdx.graphics.g2d.BitmapFont;
import com.badlogic.gdx.graphics.g2d.Sprite;
import com.badlogic.gdx.graphics.g2d.SpriteBatch;
import com.badlogic.gdx.scenes.scene2d.Stage;
import com.badlogic.gdx.utils.viewport.ExtendViewport;
import com.jkjk.GameWorld.GameRenderer;
import com.jkjk.GameWorld.GameWorld;
import com.jkjk.GameWorld.MMClient;
import com.jkjk.MMHelpers.AssetLoader;
import com.jkjk.MurderMansion.MurderMansion;

public class WaitScreen implements Screen {

	private MurderMansion game;

	private float gameWidth;
	private float gameHeight;
	private BitmapFont syncFont;
	private SpriteBatch batch;
	private BitmapFont tipFont1;
	private BitmapFont tipFont2;
	private float scale;

	private ArrayList<String> tips1;
	private ArrayList<String> tips2;
	private int randomTip;

	public WaitScreen(MurderMansion game) {
		this.game = game;
		this.gameWidth = MurderMansion.V_WIDTH;
		this.gameHeight = MurderMansion.V_HEIGHT;
		batch = new SpriteBatch();
		syncFont = AssetLoader.crimesFont36Sync;
		tipFont1 = AssetLoader.basker32WaitScreen;
		tipFont2 = AssetLoader.basker32WaitScreen;
		scale = Gdx.graphics.getWidth() / gameWidth;
		if (scale == 0)
			scale = 1;

		tips1 = new ArrayList<String>();
		tips1.add("You can checkout any time you like");
		tips1.add("Mr. M had planned this meeting for years");
		tips1.add("Civilians may run...");
		tips1.add("They laughed at my crayon drawing...");
		tips1.add("You are a victim of your own mind.");
		tips1.add("Put on headphones and turn off the lights.");
		tips1.add("Did I ever tell you the definition of INSANITY?");
		tips1.add("Fire doesn't clense. It blackens!");
		tips1.add("We're coming home.");
		tips1.add("When you stare into the darkness,");
		tips1.add("The time you enjoy wasting");
		tips1.add("Give us 5 stars.");
		tips1.add("Shotguns go...");
		tips1.add("If I hit you with a bat,");
		tips1.add("Your knife looks pretty fragile,");
		tips1.add("It's a trap!");

		tips2 = new ArrayList<String>();
		tips2.add("But you can never leave!");
		tips2.add("");
		tips2.add("But they can't hide!");
		tips2.add("I laughed at their chalk outline.");
		tips2.add("");
		tips2.add("I dare you.");
		tips2.add("");
		tips2.add("");
		tips2.add("");
		tips2.add("the darkness stares back at you.");
		tips2.add("is not time wasted.");
		tips2.add("You know you want to.");
		tips2.add("BOOM!");
		tips2.add("you would probably recover faster than I can swing again.");
		tips2.add("like it could shatter on your second use!");
		tips2.add("");

		randomTip = new Random().nextInt(tips1.size());
	}

	@Override
	public void show() {

	}

	@Override
	public void render(float delta) {
		Gdx.gl.glClearColor(0, 0, 0, 1);
		Gdx.gl.glClear(GL20.GL_COLOR_BUFFER_BIT);

		batch.begin();

		syncFont.draw(batch, "Please Wait...",
				(Gdx.graphics.getWidth() - syncFont.getBounds("Please Wait...").width) / 2, 330 * scale);
		tipFont1.draw(batch, tips1.get(randomTip),
				(Gdx.graphics.getWidth() - tipFont1.getBounds(tips1.get(randomTip)).width) / 2, 200 * scale);
		tipFont2.draw(batch, tips2.get(randomTip),
				(Gdx.graphics.getWidth() - tipFont2.getBounds(tips2.get(randomTip)).width) / 2, 160 * scale);

		batch.end();

		// System.out.println("Room state: "+game.mMultiplayerSession.mState);
		// System.out.println("Server adddress: "+game.mMultiplayerSession.serverAddress+" Server Port: "+game.mMultiplayerSession.serverPort);
		if (game.mMultiplayerSession.mState == game.mMultiplayerSession.ROOM_PLAY) {
			System.out.println("Condition fufilled!");
			// Create MMClient and connect to server
			GameWorld gWorld = new GameWorld(false);
			System.out.println("New world made");
			GameRenderer renderer = new GameRenderer(gWorld);
			System.out.println("New Renderer made");

			try {
				game.mMultiplayerSession.setClient(new MMClient(game, gWorld, renderer, false));
				System.out.println("Set new client.");

			} catch (Exception e) {
				System.out.println("Exception caught in WaitScreen!");
				e.printStackTrace();
			}
			System.out.println("Setting screen to new loading screen.");
			((Game) Gdx.app.getApplicationListener()).setScreen(new LoadingScreen(game));

		} else if (game.mMultiplayerSession.mState == game.mMultiplayerSession.ROOM_MENU) {
			game.mMultiplayerSession.mState = game.mMultiplayerSession.ROOM_NULL;
			((Game) Gdx.app.getApplicationListener()).setScreen(new MenuScreen(game));

		}
	}

	@Override
	public void resize(int width, int height) {
		scale = Gdx.graphics.getWidth() / gameWidth;
	}

	@Override
	public void hide() {
		dispose();
	}

	@Override
	public void pause() {
		System.out.println("Pause called in WaitScreen");
	}

	@Override
	public void resume() {
	}

	@Override
	public void dispose() {
	}

}
