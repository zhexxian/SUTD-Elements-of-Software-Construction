package client;

import java.io.*;
import java.net.*;

public class MinesweeperClient {
	
	private static int version;
	
	public static void main(String[] args) throws IOException {

		Socket socket = null;
		PrintWriter out = null;
		BufferedReader in = null;

		try {
			socket = new Socket("localhost", 4444);
			out = new PrintWriter(socket.getOutputStream(), true);
			in = new BufferedReader(new InputStreamReader(
					socket.getInputStream()));
		} catch (UnknownHostException e) {
			System.err.println("Don't know about host: localhost.");
			System.exit(1);
		} catch (IOException e) {
			System.err.println("Couldn't get I/O for "
					+ "the connection to: localhost.");
			System.exit(1);
		}

		BufferedReader stdIn = new BufferedReader(
				new InputStreamReader(System.in));
		String userInput;

		while ((userInput = stdIn.readLine()) != null) {
			out.println(prepareRequest(userInput));
			String output = handleResponse(in.readLine());
			System.out.println(output);
		}

		out.close();
		in.close();
		stdIn.close();
		socket.close();
	}
	
	/**
	 * helper which adds any necessary additional information to the user input before sending to server.
	 * current impl is stupidly optimistic.
	 * 
	 * @param request
	 * @return
	 */
	private static String prepareRequest(String request) {
		if(request.equals("look")) {
			return "look";
		}
		else return request + " " + version;
	}
	
	/**
	 * 
	 * @modifies this: updates our record of the server's version when possible
	 * @param response
	 * @return
	 */
	private static String handleResponse(String response) {
		if(response.startsWith("board")) {
			version = Integer.parseInt(response.split(" ")[response.split(" ").length-1]);
			String board = response.substring(response.indexOf("[")+1, response.indexOf("]"));
			board = board.replace("|", "\n");
			return board;
		} else if(response.equals("BOOM!") || response.equals("error")) {
			return response;
		} else {
			return "";
		}
	}
}