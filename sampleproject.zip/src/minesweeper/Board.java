package minesweeper;

import java.util.ArrayList;

public class Board {
	
	private int size;
	private Square[][] squares;
	
	/**
	 * this constructor is here for my testing purposes and shouldn't be what students implement
	 * 
	 * @param dim
	 * @param squares
	 */
	public Board(int size, HiddenState[][] hiddenStates) {
		this.size = size;
		squares = new Square[size][size];
		for(int i=0; i<size; i++) {
			for(int j=0; j<size; j++) {
				squares[i][j] = new Square(hiddenStates[i][j], VisibleState.UNTOUCHED);
			}
		}
	}
	
	/**
	 * Dig a square in the board
	 * 
	 * If this square is currently flagged or dug, do nothing
	 * If this results in a dug square without any neighbors with bombs, dig all neighbors.
	 * 
	 * @param x: x coordinate of square to dig
	 * @param y: y coordinate of square to dig
	 * @return true if square both was dug and has a bomb; else return false.
	 */
	public synchronized boolean dig(int x, int y) {
		return this.dig(new Coord(x,y));
	}
		
	private boolean dig(Coord c) {
		int x = c.getX();
		int y = c.getY();
		if((x < 0 || x >= size) || (y < 0 || y >= size)) {
			return false;
		}
		boolean bomb = false;
		Square s = this.squares[x][y];
		if(s.getVisibleState() == VisibleState.UNTOUCHED) {
			// dig the square, set return value as appropriate
			s.setVisibleState(VisibleState.DUG);
			if(s.getHiddenState() == HiddenState.BOMB) {
				//BOOM!
				s.setHiddenState(HiddenState.NO_BOMB);
				bomb = true;
			}
			this.clearBoard();
		}
		return bomb;
	}

	/**
	 * Flag the current square if it is currently untouched
	 *
	 * @param x
	 * @param y
	 */
	public synchronized void flag(int x, int y) {
		if((x < 0 || x >= size) || (y < 0 || y >= size)) {
			return;
		}
		Square s = this.squares[x][y];
		VisibleState prev = s.getVisibleState();
		if(prev == VisibleState.UNTOUCHED) {
			s.setVisibleState(VisibleState.FLAGGED);
		}
	}
	
	/**
	 * Change square to untouched if it is currently flagged
	 * 
	 * @param x
	 * @param y
	 */
	public synchronized void deflag(int x, int y) {
		if((x < 0 || x >= size) || (y < 0 || y >= size)) {
			return;
		}
		Square s = this.squares[x][y];
		VisibleState prev = s.getVisibleState();
		if(prev == VisibleState.FLAGGED) {
			s.setVisibleState(VisibleState.UNTOUCHED);
		}
	}
	
	/**
	 * Produce a readable representation of the visible board state
	 */
	public String toString() {
		String result = "";
		for(int i=0; i<this.size; i++) {
			for(int j=0; j<this.size; j++) {
				result += squareString(i,j);
				if(j < (this.size-1)) {
					result += " ";
				}
			}
			if(i < (this.size - 1)) {
				result += "\n";
			}
		}
		return result;
	}
	
	/**
	 * Helper method which gives a string for a square, indicating 
	 * its visible state, and if the latter is "dug", also indicating
	 * the number of neighbor squares which have bombs
	 */
	private String squareString(int x, int y) {
		Square s = this.squares[x][y];
		if(s.getVisibleState() == VisibleState.UNTOUCHED) {
			//return "U";
			return "-";
		} else if (s.getVisibleState() == VisibleState.FLAGGED) {
			return "F";
		} else if (s.getVisibleState() == VisibleState.DUG) {
			int bombs = 0;
			// return 1-8 if corresponding # of neighbors have bombs;
			for(Coord c : this.getNeighborCoords(x,y)) {
				if(this.getSquare(c).getHiddenState() == HiddenState.BOMB) {
					bombs++;
				}
			}
			if(bombs == 0) {
				//return ".";
				return " ";
			} else {
				return ""+bombs;
			}
		} else {
			//this should never happen
			throw new RuntimeException("square.visibleState should be in VisibleState enum");
		}
	}
	
	/**
	 * helper method which loops over the board, digging any undug neighbors of dug squares which 
	 * have no neighboring bombs
	 */
	private void clearBoard() {
		boolean dug;
		do {
			dug = false;
			for (int i=0; i<size; i++) {
				for (int j=0; j<size; j++) {
					if (this.squares[i][j].getVisibleState().equals(VisibleState.DUG)) {
						int neighbombs = 0;
						ArrayList<Coord> neighborCoords = this.getNeighborCoords(i, j);
						for(Coord c : neighborCoords) {
							if (this.getSquare(c).getHiddenState().equals(HiddenState.BOMB)) {
								neighbombs++;
							}
						}
						if (neighbombs == 0) {
							//this is a dug state with no neighbor bombs.  dig all its hitherto-undug neighbors.
							for(Coord c : neighborCoords) {
								if(this.getSquare(c).getVisibleState().equals(VisibleState.UNTOUCHED)) {
									dug = true;
									this.dig(c);
								}
							}
						}
					}
				}
			}
		} while (dug);
	}
	
	private Square getSquare(Coord c) {
		return this.squares[c.getX()][c.getY()];
	}
	
	/**
	 * helper method which returns all neighbor squares to the square of given coordinates
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	private ArrayList<Coord> getNeighborCoords(int x, int y) {
		ArrayList<Coord> result = new ArrayList<Coord>();
		for(int i = x-1; i <= x+1; i++) {
			for(int j = y-1; j <= y+1; j++) {
				if(this.inBounds(i,j)) {
					result.add(new Coord(i,j));
				}
			}
		}
		return result;
	}
	
	/**
	 * helper method which checks whether an x,y coordinate is within the bounds of the board
	 * 
	 * @param x
	 * @param y
	 * @return
	 */
	private boolean inBounds(int x, int y) {
		return ((x < this.size) && (y < this.size)) && ((x >= 0) && (y >= 0));
	}


}
