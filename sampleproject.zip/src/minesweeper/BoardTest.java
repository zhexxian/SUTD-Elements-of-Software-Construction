package minesweeper;

import static org.junit.Assert.*;

import org.junit.Test;

public class BoardTest {

	@Test
	public void constructorViewTest() {
		String expected = "[ U U U U | U U U U | U U U U | U U U U ]";
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		String sboard = board.toString();
		assertTrue(sboard.startsWith(expected));
	}
	
	@Test
	public void flagTest()/* throws BoardVersionException*/ {
		String expected = "[ U U F U | U U U U | U U U U | U U U U ]";
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		board.flag(0, 2);
		String sboard = board.toString();
		assertTrue(sboard.startsWith(expected));
	}
	
	@Test
	public void deflagTest()/* throws BoardVersionException*/ {
		String expected = "[ U F U U | U U U U | U U U U | U U U U ]";
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		board.flag(0, 1);
		board.flag(0, 2);
		board.flag(0, 3);
		board.deflag(0, 2);
		board.deflag(0, 3);
		board.deflag(1, 3);
		String sboard = board.toString();
		assertTrue(sboard.startsWith(expected));
	}
	
	@Test
	public void digAdjacentTest() /*throws BoardVersionException */{
		String expected = "[ U U 1 U | U U U U | U U U U | U U U U ]";
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		board.dig(0, 2);
		String sboard = board.toString();
		assertTrue(sboard.startsWith(expected));
	}
	
	@Test
	public void digNonAdjacentTest()/* throws BoardVersionException*/ {
		String expected = "[ . . 1 U | 1 1 1 U | U U U U | U U U U ]";
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		board.dig(0, 1);
		String sboard = board.toString();
		assertTrue(sboard.startsWith(expected));
	}
	
	@Test
	public void digReturnValsTest()/* throws BoardVersionException*/ {
		int s = 4;
		HiddenState b = HiddenState.BOMB;
		HiddenState n = HiddenState.NO_BOMB;
		HiddenState[][] hs = {{n, n, n, b}, {n, n, n, n}, {b, n, n, n}, {n, n, b, n}};
		Board board = new Board(s, hs);
		assertTrue(board.dig(0, 3));
		assertFalse(board.dig(0, 3));
	}

}
