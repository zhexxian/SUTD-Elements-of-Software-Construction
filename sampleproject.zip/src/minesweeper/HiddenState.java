package minesweeper;

public enum HiddenState {

	BOMB,NO_BOMB

}
