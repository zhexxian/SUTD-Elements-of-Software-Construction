package minesweeper;

public class Square {
	
	private HiddenState hiddenState;
	private VisibleState visibleState;
	
	public Square(HiddenState hiddenState, VisibleState visibleState) {
		this.hiddenState = hiddenState;
		this.visibleState = visibleState;
	}
	
	public HiddenState getHiddenState() {
		return hiddenState;
	}
	public void setHiddenState(HiddenState hiddenState) {
		this.hiddenState = hiddenState;
	}
	public VisibleState getVisibleState() {
		return visibleState;
	}
	public void setVisibleState(VisibleState visibleState) {
		this.visibleState = visibleState;
	}

}
