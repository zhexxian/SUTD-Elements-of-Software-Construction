package minesweeper;

public enum VisibleState {
	
	FLAGGED,DUG,UNTOUCHED

}
