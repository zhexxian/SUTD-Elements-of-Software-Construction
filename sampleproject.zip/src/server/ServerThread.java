package server;

import java.net.*;
import java.io.*;

import minesweeper.Board;

public class ServerThread extends Thread {
	private Socket socket = null;
	private Board board;

	public ServerThread(Socket socket, Board board) {
		super("ServerThread");
		this.socket = socket;
		this.board = board;
	}

	public void run() {

		try {
			PrintWriter out = new PrintWriter(socket.getOutputStream(), true);
			BufferedReader in = new BufferedReader(
					new InputStreamReader(
							socket.getInputStream()));

			String inputLine, outputLine;
			// this line is total bullshit (N=2) but it's a hack to get the user/server protocol 
			// consistent with the final handout release.
			out.println("Welcome to Minesweeper.  2 people are playing including you.  Type 'help' for help.");

			while ((inputLine = in.readLine()) != null) {
				
				outputLine = handleRequest(inputLine);
				
				if(outputLine != null) {
					System.out.println(outputLine);
					out.println(outputLine);
					//exploding a bomb kicks the player off the server unless we're in debug mode
					if(!MinesweeperServer.isDebug() && outputLine.equals("BOOM!")) {
						break;
					}
				}
			}
			out.close();
			in.close();
			socket.close();

		} catch (IOException e) {
			e.printStackTrace();
		}
	}
	
	/**
	 * handler for client input
	 * 
	 * make requested mutations on game state if applicable, then return appropriate message to the user
	 * 
	 * @param input
	 * @return
	 */
	private String handleRequest(String input)/* throws BoardVersionException*/ {
		
		System.out.println("input = "+input);
		
		String regex = "((look)|(dig \\d+ \\d+)|(flag \\d+ \\d+)|(deflag \\d+ \\d+))";
		if(!input.matches(regex)) {
			//invalid input
			return null;
		}
		String resp = null;
		
		String[] tokens = input.split(" ");
		if(tokens[0].equals("look")) {
			resp =  board.toString();
		} else {
			int x = Integer.parseInt(tokens[1]);
			int y = Integer.parseInt(tokens[2]);
			if(tokens[0].equals("dig")) {
				boolean bomb = board.dig(x, y);
				if(bomb) {
					resp = "BOOM!";
				} else {
					resp = board.toString();
				}
			} else if(tokens[0].equals("flag")) {
				board.flag(x, y);
				// this isn't actually threadsafe in that these 2 lines should be atomic.
				resp = board.toString();
			} else if(tokens[0].equals("deflag")) {
				board.deflag(x, y);
				resp = board.toString();
			}
		}
		return resp;
	}
}