package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.Before;
import org.junit.Test;

public class BlankBoardFileTest {

	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false","-f","src/test/board_file_1"});
	}

	@Test(timeout = 10000)
	public void testBlankBoardFile() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);

		String expected = "- - - - - - - - - - -";
		
		Socket sock;
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(), true);
			//throw away first line; look for BOARD msg.
			try {
				in.readLine();
			} catch(SocketTimeoutException ignored) {}

			out.println("look");
			String moo;
			for(int i=0; i<11; i++) {
				moo = in.readLine();
				while(moo.equals("")) moo = in.readLine();
				assertTrue(TestUtil.eqNoSpace(expected, moo));
			}
			sock.close();
		} catch (SocketTimeoutException e) {
			fail("server timeout");
		}
	}

}
