package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.Before;
import org.junit.Test;

/**
 * check to make sure the server disconnects us after we get a boom.
 * implemented in a prettty hacky way
 * 
 * @author njoliat
 *
 */
public class BoomDisconnectTest {

	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false","-f","src/test/board_file_2"});
	}

	@Test(timeout=10000)
	public void testBoomDisconnect() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		
		Socket sock;
		
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			out.println("dig 1 1");
			// burn through any server messages
			// (i don't care about checking them for this test)
			for(int i=0; i<20; i++) {
				in.readLine();
			}
			assertTrue("if we're disconnected readLine should give a null",in.readLine() == null);
			sock.close();
		} catch (SocketTimeoutException e) {
			fail("readLine timed out");
		}
	}
}
