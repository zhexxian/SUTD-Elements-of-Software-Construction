package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.Before;
import org.junit.Test;

/**
 * check to make sure the server disconnects us after we send it "bye".
 * implemented in a prettty hacky way
 * 
 * @author njoliat
 *
 */
public class ByeTest {

	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false"});
	}

	@Test(timeout=10000)
	public void byeTest() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		
		Socket sock;
		
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			out.println("bye");
			// burn through any server messages
			// (i don't care about spurious ones for this test)
			for(int i=0; i<20; i++) {
				in.readLine();
			}
			// it's probable that the server won't be sending a bunch of 
			// nulls to us, so if we get this it's probably because the
			// server booted us, which is what we want.
			assertTrue("if we're disconnected readLine should give a null",in.readLine() == null);
			sock.close();
		} catch (SocketTimeoutException e) {
			fail("readLine timed out");
		}
		//we want a help message which is exactly one line.
	}

}
