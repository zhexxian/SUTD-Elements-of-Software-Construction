package test;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.SocketTimeoutException;
import java.util.concurrent.atomic.AtomicBoolean;

import org.junit.Before;
import org.junit.Test;

public class HelloTestMulti {
	
	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false"});
	}

	@Test(timeout=10000)
	public void helloMulti() throws IOException, InterruptedException {
		final int THREADS = 10;

		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		
		AtomicBoolean noTimeout = new AtomicBoolean(true);
		AtomicBoolean noIOError = new AtomicBoolean(true);

		Thread threads[] = new Thread[THREADS];

		class ConnectTestRunner implements Runnable {
			private AtomicBoolean noTimeout;
			private AtomicBoolean noIOError;
			
			public ConnectTestRunner(AtomicBoolean t, AtomicBoolean io) {
				this.noTimeout = t;
				this.noIOError = io;
			}
			
			public void run() {
				Socket sock;
				try {
					sock = new Socket("127.0.0.1",4444);
					sock.setSoTimeout(3000);
					BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
					String moo = in.readLine();
					assertTrue(moo != null);
				} catch (SocketTimeoutException e) {
					this.noTimeout.set(false);
				} catch (IOException e) {
					this.noIOError.set(false);
				}
			}
		}
		
		
		for(int i=0; i<THREADS; i++) {
			threads[i] = new Thread(new ConnectTestRunner(noTimeout,noIOError));
		}
		for(int i=0; i<THREADS; i++) {
			threads[i].start();
		}
		for(int i=0; i<THREADS; i++) {
			threads[i].join();
		}
		assertTrue("server timeout", noTimeout.get());
		assertTrue("server io error", noIOError.get());
	}
}
