package test;

import static org.junit.Assert.assertArrayEquals;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;

import org.junit.Before;
import org.junit.Test;

public class MinesweeperSystemTest {

	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false","-f","src/test/board_file_3"});
	}

	/**
	 * hold a 3-client game with a series of interleaving operations.
	 * 
	 * 0 f 0 0 0 f
	 * 0 0 0 f 0 0
	 * 1 f 1 1 1 1
	 * d 0 0 0 0 0
	 * d 0 0 0 d 0
	 * 1 0 0 d 0 0
	 * 
	 * - f - - - f
	 * - - - f - -
	 * - f - - - -
	 * 2 3 3 3 3 2
	 * 1 1        
	 * - 1        
	 * 
	 * flag: 0,1   0,5   1,3   2,1
	 * dig: 3,0   4,0   4,4   5,3
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(timeout=20000)
	public void systemTest() throws IOException, InterruptedException {
		final int THREADS = 3;
		
		String expected[] = new String[] {
				"- F - - - F",
				"- - - F - -",
				"- F - - - -",
				"2 3 3 3 3 2",
				"1 1        ",
				"- 1        "
		};

		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		
		Thread threads[] = new Thread[THREADS];
		
		threads[0] = new Thread(new Runnable() {
			public void run() {
				try {
					Socket sock = new Socket("127.0.0.1",4444);
					sock.setSoTimeout(3000);
					PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
					out.println("flag 0 1");
					out.println("dig 3 0");
					out.println("flag 0 5");
					out.println("dig 4 0");
					out.println("flag 1 3");
					out.close();
					sock.close();
				} catch (Exception ignored) {}
			}
		});
		threads[1] = new Thread(new Runnable() {
			public void run() {
				try {
					Socket sock = new Socket("127.0.0.1",4444);
					sock.setSoTimeout(3000);
					PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
					out.println("dig 4 4");
					out.println("flag 1 3");
					out.println("dig 5 3");
					out.println("flag 2 1");
					out.println("dig 3 0");
					out.close();
					sock.close();
				} catch (Exception ignored) {}
			}
		});
		threads[2] = new Thread(new Runnable() {
			public void run() {
				try {
					Socket sock = new Socket("127.0.0.1",4444);
					sock.setSoTimeout(3000);
					PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
					out.println("flag 2 1");
					out.println("dig 4 0");
					out.println("flag 0 1");
					out.println("dig 4 4");
					out.println("flag 0 5");
					out.close();
					sock.close();
				} catch (Exception ignored) {}
			}
		});
		
		for(int i=0; i<THREADS; i++) {
			threads[i].start();
		}
		for(int i=0; i<THREADS; i++) {
			threads[i].join();
		}
		Thread.sleep(3000);
		try {
			Socket sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			out.println("look");
			//burn hello line
			in.readLine();
			
			String response[] = new String[6];
			for(int i=0; i<6; i++) {
				response[i] = in.readLine();
				System.out.println(response[i]);
			}
			
			assertArrayEquals(expected, response);
			
		} catch (Exception e) {
			fail("exception in thread 0");
		}
		
	}

}
