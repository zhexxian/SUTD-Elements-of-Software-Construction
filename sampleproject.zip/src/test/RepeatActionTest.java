package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.BeforeClass;
import org.junit.Test;

public class RepeatActionTest {
	@BeforeClass
	public static void setUpOnce() {
		TestUtil.startServer(new String[] {"false","-f","src/test/board_file_2"});
	}

	@Test(timeout=10000)
	public void repeatDigTest() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		Socket sock;
		
		String expected[] = new String[] {
				"3 - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -"
		};
		
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			out.println("dig 0 0");
			out.println("dig 0 0");
			String moo;

			//throw away first line + 2 boards msgs.
			try {
				for(int i=0; i<13; i++) {
					moo = in.readLine();
					while(moo.equals("")) moo = in.readLine();
				}
			} catch (SocketTimeoutException ignored){}
			
			out.println("dig 0 0");
			for(int i=0; i<6; i++) {
				moo = in.readLine();
				while(moo.equals("")) moo = in.readLine();
				assertTrue(TestUtil.eqNoSpace(expected[i],moo));
			}
			sock.close();
		} catch (SocketTimeoutException e) {
			//want to get this on third readLine.
			fail("server timeout");
		}
	}
	
	@Test(timeout=10000)
	public void repeatFlagTest() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		Socket sock;
		
		String expected[] = new String[] {
				"3 - - - - -",
				"- F - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -"
		};
		
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			out.println("flag 1 1");
			out.println("flag 1 1");
			
			//throw away hello + 2 boards.
			String moo;
			try{
				for(int i=0; i<13; i++) {
					moo = in.readLine();
					while(moo.equals("")) moo = in.readLine();
				}
			} catch(SocketTimeoutException ignored){}

			out.println("flag 1 1");
			for(int i=0; i<6; i++) {
				moo = in.readLine();
				while(moo.equals("")) moo = in.readLine();
				assertTrue(TestUtil.eqNoSpace(expected[i],moo));
			}
			sock.close();
		} catch (SocketTimeoutException e) {
			//want to get this on third readLine.
			fail("server timeout");
		}
	}
	
	@Test
	public void newConnectionRepeatTest() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		Socket sock;
		
		String expected[] = new String[] {
				"3 - - - - -",
				"- F - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -"
		};
		
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
			String moo;
			
			//throw away first line; look for BOARD msg.
			try {
				moo = in.readLine();
				while(moo.equals("")) moo = in.readLine();
			} catch(SocketTimeoutException ignored){}

			out.println("dig 0 0");
			for(int i=0; i<6; i++) {
				moo = in.readLine();
				while(moo.equals("")) moo = in.readLine();
				assertTrue(TestUtil.eqNoSpace(expected[i],moo));
			}
			sock.close();
		} catch (SocketTimeoutException e) {
			//want to get this on third readLine.
			fail("server timeout");
		}
	}

}
