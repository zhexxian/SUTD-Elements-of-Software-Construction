package test;

import static org.junit.Assert.assertTrue;
import static org.junit.Assert.fail;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.Before;
import org.junit.Test;

public class ServerCountTest {

	@Before
	public void setUp() {
		TestUtil.startServer(new String[] {"false"});
	}

	/**
	 * open 5 client connections, check the N in hello msg on the 6th one.
	 * 
	 * @throws IOException
	 * @throws InterruptedException
	 */
	@Test(timeout=10000)
	public void testServerCount() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		final int THREADS = 3;

		Thread threads[] = new Thread[THREADS];
		
		for(int i=0; i<THREADS; i++) {
			threads[i] = new Thread(new Runnable() {
				public void run() {
					Socket sock;
					try {
						sock = new Socket("127.0.0.1",4444);
						sock.setSoTimeout(3000);
						BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
						String moo = in.readLine();
						assertTrue(moo != null);
					} catch (IOException ignored) {}
				}
			});
		}
		for(int i=0; i<THREADS; i++) {
			threads[i].start();
		}
		
		Thread.sleep(2000);
		
		final String expected = "Welcome to Minesweeper.  "+(THREADS+1)+" people are playing including you.  Type 'help' for help.";

		Socket sock;
		try {
			sock = new Socket("127.0.0.1",4444);
			sock.setSoTimeout(3000);
			BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
			String moo = in.readLine();
			assertTrue(TestUtil.eqNoSpace(expected,moo));
			sock.close();
		} catch (SocketTimeoutException e) {
			fail("server timeout");
		}
	}
}
