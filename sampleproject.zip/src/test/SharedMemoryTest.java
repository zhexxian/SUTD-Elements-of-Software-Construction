package test;

import static org.junit.Assert.assertTrue;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.net.SocketTimeoutException;

import org.junit.BeforeClass;
import org.junit.Test;

/**
 * Make sure that if player 1 alters the board, player 2 seems the same change.
 * 
 * @author njoliat
 *
 */
public class SharedMemoryTest {

	@BeforeClass
	public static void setUpOnce() {
		TestUtil.startServer(new String[] {"false","-f","src/test/board_file_2"});
	}

	@Test(timeout=10000)
	public void twoBoardFlagTest() throws IOException, InterruptedException {
		// avoid race where we try to connect to server too early
		Thread.sleep(100);
		Socket sock;
		
		String expected[] = new String[] {
				"- - - - - -",
				"- F - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -",
				"- - - - - -"
		};

		new Thread(new Runnable() {public void run() {
				Socket sock;
				try {
					sock = new Socket("127.0.0.1",4444);
					sock.setSoTimeout(3000);
					PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
					out.println("flag 1 1");
				} catch (IOException ignored) {}
			}
		}).start();
		
		Thread.sleep(4000);
		sock = new Socket("127.0.0.1",4444);
		sock.setSoTimeout(3000);
		BufferedReader in = new BufferedReader(new InputStreamReader(sock.getInputStream()));
		PrintWriter out = new PrintWriter(sock.getOutputStream(),true);
		String moo;
		
		//throw away first line; in.readLine();
		try {
			moo = in.readLine();
			while(moo.equals("")) moo = in.readLine();
		} catch(SocketTimeoutException ignored){}
		
		out.println("look");
		for(int i=0; i<6; i++) {
			moo = in.readLine();
			while(moo.equals("")) moo = in.readLine();
			assertTrue(TestUtil.eqNoSpace(expected[i],moo));
		}
		sock.close();
		
	}

}
