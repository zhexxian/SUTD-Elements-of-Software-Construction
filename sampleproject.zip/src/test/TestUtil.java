package test;

// yeah, this doesn't compile in ps6-njoliat, because my package 
// structure's wrong there.
import minesweeper.server.MinesweeperServer;

public class TestUtil {
	
	public static void startServer(String args[]) {
		final String myArgs[] = args;
		new Thread(new Runnable() {
			public void run() {
				try {
					MinesweeperServer.main(myArgs);
				} catch (Exception e) {
					e.printStackTrace();
					return;
				}
			}
		}).start();
	}
	
	public static boolean eqNoSpace(String s1, String s2) {
		System.out.println("ex "+s1);
		System.out.println("ac "+s2);
		return s1.replaceAll("\\s+", "").equals(s2.replaceAll("\\s+", ""));
	}
}
